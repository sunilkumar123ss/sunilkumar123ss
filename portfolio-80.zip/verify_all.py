"""Verify the original standalone reference suites; enhanced RagKit has separate checks."""
from pathlib import Path
import concurrent.futures, datetime, json, platform, re, subprocess, sys
ROOT=Path(__file__).resolve().parent
OUT=ROOT
entries=json.loads((OUT/'manifest.json').read_text())
def check(item):
    repo=OUT/'repositories'/item['slug']
    results=[]
    for name,args,cwd,expected in [
        ('tests',['-m','unittest','discover','-s','.','-p','test_main.py','-v'],repo,0),
        ('demo',[str(repo/'main.py')]+item.get('demo_args',[]),ROOT,item.get('expected_exit',0)),
        ('help',[str(repo/'main.py'),'--help'],ROOT,0)]:
        try:
            p=subprocess.run([sys.executable]+args,cwd=cwd,text=True,capture_output=True,timeout=35)
            count=re.search(r'Ran (\d+) tests?',p.stderr) if name=='tests' else None
            passed=p.returncode==expected and (name!='tests' or count and int(count.group(1))>0)
            results.append(dict(check=name,passed=bool(passed),exit_code=p.returncode,expected_exit=expected,test_count=int(count.group(1)) if count else 0,stdout=p.stdout,stderr=p.stderr))
        except subprocess.TimeoutExpired:
            results.append(dict(check=name,passed=False,error='35-second timeout',test_count=0))
    return dict(repository=item['slug'],passed=all(x['passed'] for x in results),checks=results)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    results=list(pool.map(check,entries))
report=dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=platform.python_version(),repositories=len(entries),tests=sum(x['test_count'] for r in results for x in r['checks']),demo_checks=len(entries),help_checks=len(entries),passed=len(entries)==80 and all(x['passed'] for x in results),scope='Baseline standalone reference suites (test_main.py), synthetic main.py demos and CLI help across all 80 packages. This does not run RagKit application, integration or neural-model tests; see repositories/RagKit/docs/VERIFICATION.md. No external service, deployment, production throughput or hosted CI claim.',results=results)
(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
for row in results:
    if not row['passed']: print(json.dumps(row,indent=2))
sys.exit(0 if report['passed'] else 1)
