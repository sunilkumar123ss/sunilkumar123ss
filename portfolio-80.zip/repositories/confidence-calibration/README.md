# Confidence calibration

Inspect binary probability outputs using Brier score, log loss, reliability bins, and expected calibration error (ECE). The fixture is synthetic; this program does not generate model probabilities.

~~~sh
python3 main.py --input example.json --bins 5
python3 -m unittest -v
~~~

ECE compares mean positive-class probability with observed positive rate in equal-width bins. Bins include their lower boundary; only the last includes its upper boundary of 1. Empty bins have null means and contribute zero. Log-loss inputs are clipped at 1e-15 and 1−1e-15 so impossible predictions produce large finite losses. Brier score uses the original probabilities.

ECE changes with bin count and sample size. A low ECE alone does not imply useful discrimination, balanced errors, or suitability for deployment.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
