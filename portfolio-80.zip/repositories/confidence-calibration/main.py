"""Binary probability calibration diagnostics without model inference."""
import argparse
import json
from pathlib import Path
import math
import sys


def evaluate(probabilities, outcomes, bins=10):
    if type(bins) is not int or not 1 <= bins <= 1000:
        raise ValueError("bins must be an integer from 1 to 1000")
    if not isinstance(probabilities, list) or not isinstance(outcomes, list):
        raise ValueError("probabilities and outcomes must be lists")
    if not probabilities or len(probabilities) != len(outcomes):
        raise ValueError("equal, nonempty probability and outcome lists required")
    if any(type(p) not in (int, float) or not math.isfinite(p) or not 0 <= p <= 1 for p in probabilities):
        raise ValueError("probabilities must be finite numbers in [0,1]")
    if any(type(y) is not int or y not in (0, 1) for y in outcomes):
        raise ValueError("outcomes must be integer 0 or 1")
    buckets = [[] for _ in range(bins)]
    for p, y in zip(probabilities, outcomes):
        buckets[min(int(p * bins), bins - 1)].append((p, y))
    reliability, ece = [], 0.0
    for index, bucket in enumerate(buckets):
        mean_p = sum(p for p, _ in bucket) / len(bucket) if bucket else None
        rate = sum(y for _, y in bucket) / len(bucket) if bucket else None
        if bucket:
            ece += len(bucket) / len(outcomes) * abs(mean_p - rate)
        reliability.append(dict(lower=index / bins, upper=(index + 1) / bins,
                                count=len(bucket), mean_probability=mean_p, positive_rate=rate))
    clipped = [min(max(p, 1e-15), 1 - 1e-15) for p in probabilities]
    log_loss = -sum(y * math.log(p) + (1 - y) * math.log1p(-p) for p, y in zip(clipped, outcomes)) / len(outcomes)
    return {"samples": len(outcomes), "brier_score": sum((p - y) ** 2 for p, y in zip(probabilities, outcomes)) / len(outcomes),
            "log_loss": log_loss, "ece": ece, "reliability_bins": reliability}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--bins", type=int, default=5)
    args = parser.parse_args()
    try:
        input_path = Path(args.input)
        if not input_path.is_absolute():
            input_path = Path(__file__).resolve().parent / input_path
        with input_path.open(encoding="utf-8") as handle:
            data = json.load(handle)
        print(json.dumps(evaluate(data["probabilities"], data["outcomes"], args.bins), indent=2, allow_nan=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(f"Invalid calibration data: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
