import math
import unittest
from main import evaluate


class CalibrationTests(unittest.TestCase):
    def test_known_scores(self):
        result = evaluate([0.25, 0.75], [0, 1], 2)
        self.assertAlmostEqual(result["brier_score"], 0.0625)
        self.assertAlmostEqual(result["log_loss"], -math.log(0.75))
        self.assertEqual(result["ece"], 0.25)

    def test_endpoints_and_empty_bins(self):
        result = evaluate([0, 1], [0, 1], 4)
        self.assertEqual(result["ece"], 0)
        self.assertEqual(result["reliability_bins"][-1]["count"], 1)
        self.assertIsNone(result["reliability_bins"][1]["positive_rate"])
        self.assertTrue(math.isfinite(evaluate([0], [1])["log_loss"]))

    def test_invalid_data(self):
        for p, y in [([], []), ([float("nan")], [0]), ([1.1], [1]), ([0.5], [2]), ([True], [1])]:
            with self.subTest(p=p), self.assertRaises(ValueError):
                evaluate(p, y)
        with self.assertRaises(ValueError):
            evaluate([0.5], [1], 0)


if __name__ == "__main__":
    unittest.main()
