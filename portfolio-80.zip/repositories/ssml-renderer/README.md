# Restricted Safe SSML Renderer

**Demo/starter · Python standard library only.**

Render escaped SSML from structured text, emphasis and pause segments.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json --rate slow
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input is a JSON list: `{text}`, `{kind:"emphasis", text, level}` or `{kind:"break", ms}`. Allowed rates are x-slow, slow, medium, fast and x-fast. Text order is preserved. Embedded markup is escaped as text; unsupported tags and invalid XML characters are rejected.

## Limits and optional provider boundary

This is a restricted SSML subset, not a full validator or TTS engine. Provider support varies. Limits are 100 segments, 5,000 characters per text segment and 10,000 ms per break. No audio, network or remote pronunciation references are used.

A separately configured TTS adapter may receive the XML and must check its own constraints. This project renders XML only. Escaping prevents the supplied text from becoming markup in this renderer; it is not a universal injection-immunity guarantee for downstream applications or providers.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
