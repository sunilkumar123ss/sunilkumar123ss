"""Render a restricted, escaped SSML document from structured text segments."""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

def safe_text(value):
    if not isinstance(value, str):
        raise ValueError('Text must be a string')
    if len(value) > 5000:
        raise ValueError('Text segment exceeds5000characters')
    for char in value:
        code = ord(char)
        if not (code in (9, 10, 13) or 32 <= code <= 55295 or 57344 <= code <= 65533 or (65536 <= code <= 1114111)):
            raise ValueError('Text contains an invalid XML character')
    return value

def render(segments, rate='medium'):
    if not isinstance(rate, str) or rate not in {'x-slow', 'slow', 'medium', 'fast', 'x-fast'}:
        raise ValueError('Unsupported prosody rate')
    if not isinstance(segments, list) or len(segments) > 100:
        raise ValueError('Provide at most100segments')
    root = ET.Element('speak', {'version': '1.0', 'xml:lang': 'en-US'})
    prosody = ET.SubElement(root, 'prosody', {'rate': rate})
    for segment in segments:
        if not isinstance(segment, dict):
            raise ValueError('Segment must be an object')
        kind = segment.get('kind', 'text')
        if not isinstance(kind, str):
            raise ValueError('kind must be a string')
        if kind == 'break':
            duration = segment.get('ms')
            if isinstance(duration, bool) or not isinstance(duration, int) or (not 0 <= duration <= 10000):
                raise ValueError('Break must be integer0..10000ms')
            ET.SubElement(prosody, 'break', {'time': str(duration) + 'ms'})
        elif kind in {'text', 'emphasis'}:
            text = safe_text(segment.get('text'))
            if kind == 'emphasis':
                level = segment.get('level', 'moderate')
                if not isinstance(level, str) or level not in {'reduced', 'moderate', 'strong'}:
                    raise ValueError('Unsupported emphasis level')
                ET.SubElement(prosody, 'emphasis', {'level': level}).text = text
            elif len(prosody):
                last = prosody[-1]
                last.tail = (last.tail or '') + text
            else:
                prosody.text = (prosody.text or '') + text
        else:
            raise ValueError('Unsupported SSML segment kind')
    return ET.tostring(root, encoding='unicode', short_empty_elements=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON list of text,emphasis orbreak segments')
    parser.add_argument('--rate', default='medium')
    args = parser.parse_args()
    try:
        segments = json.loads(args.input.read_text()) if args.input else [{'text': 'Your balance is <private> & unavailable.'}, {'kind': 'break', 'ms': 300}, {'kind': 'emphasis', 'text': 'Please sign in securely.', 'level': 'moderate'}]
        print(render(segments, args.rate))
    except (ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
