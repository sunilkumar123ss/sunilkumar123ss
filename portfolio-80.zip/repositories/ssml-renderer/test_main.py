import unittest
import xml.etree.ElementTree as ET
try:
    from .main import render
except ImportError:
    from main import render

class SsmlTests(unittest.TestCase):

    def test_markup_is_text_not_injection(self):
        text = '<audio src="https://example.invalid"/> & hello'
        xml = render([{'text': text}])
        root = ET.fromstring(xml)
        self.assertEqual(root.find('prosody').text, text)
        self.assertIsNone(root.find('.//audio'))

    def test_order_and_tail(self):
        xml = render([{'text': 'a'}, {'kind': 'break', 'ms': 20}, {'text': 'b'}, {'kind': 'emphasis', 'text': 'c'}, {'text': 'd'}])
        p = ET.fromstring(xml).find('prosody')
        self.assertEqual(''.join(p.itertext()), 'abcd')
        self.assertEqual(p[0].get('time'), '20ms')

    def test_invalid(self):
        for segments in [[{'kind': 'audio', 'text': 'x'}], [{'text': '\x00'}], [{'kind': 'break', 'ms': -1}], [{'kind': 'emphasis', 'text': 'x', 'level': 'unsafe'}]]:
            with self.assertRaises(ValueError):
                render(segments)
        with self.assertRaises(ValueError):
            render([], '200% malicious')

    def test_empty_and_unicode(self):
        self.assertEqual(ET.fromstring(render([])).tag, 'speak')
        self.assertIn('नमस्ते', render([{'text': 'नमस्ते'}]))

    def test_size_limit(self):
        with self.assertRaises(ValueError):
            render([{'text': 'a' * 5001}])
if __name__ == '__main__':
    unittest.main()
