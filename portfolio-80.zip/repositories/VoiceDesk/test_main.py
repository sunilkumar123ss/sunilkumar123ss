import unittest
from main import VoiceSession, replay


class SessionTests(unittest.TestCase):
    def event(self, session, seq, kind, **fields):
        return session.apply(dict(seq=seq, type=kind, **fields))

    def test_partial_is_replaced_then_committed(self):
        s = VoiceSession()
        self.event(s, 1, "user_partial", text="hel")
        self.event(s, 2, "user_partial", text="hello")
        self.assertEqual(s.turns, [])
        self.event(s, 3, "user_final", text="hello world")
        self.assertEqual(s.partial, "")
        self.assertEqual(s.turns, [{"speaker":"user", "text":"hello world"}])

    def test_barge_in_cancels_once_and_drops_late_chunks(self):
        s = VoiceSession()
        self.event(s, 1, "user_final", text="hello")
        self.event(s, 2, "assistant_start", reply_id="a")
        self.event(s, 3, "assistant_chunk", reply_id="a", text="Hi")
        out = self.event(s, 4, "user_partial", text="stop")
        self.assertEqual(out[0]["type"], "cancel_playback")
        self.assertTrue(s.turns[-1]["interrupted"])
        self.assertEqual(self.event(s, 5, "assistant_chunk", reply_id="a", text="late")[0]["type"], "stale_reply_ignored")
        self.assertNotIn("late", str(s.turns))

    def test_normal_chunks_are_joined(self):
        s = VoiceSession()
        for seq, kind, extra in [(1,"user_final",{"text":"hi"}), (2,"assistant_start",{"reply_id":"x"}),
                                 (3,"assistant_chunk",{"reply_id":"x","text":"Hello "}),
                                 (4,"assistant_chunk",{"reply_id":"x","text":"there"}),
                                 (5,"assistant_end",{"reply_id":"x"})]:
            self.event(s, seq, kind, **extra)
        self.assertEqual(s.turns[-1]["text"], "Hello there")
        self.assertFalse(s.turns[-1]["interrupted"])

    def test_duplicate_sequence_is_rejected_without_mutation(self):
        s = VoiceSession()
        self.event(s, 1, "user_final", text="hi")
        with self.assertRaises(ValueError): self.event(s, 1, "user_final", text="again")
        self.assertEqual(len(s.turns), 1)

    def test_close_is_terminal(self):
        s = VoiceSession()
        self.event(s, 1, "close")
        with self.assertRaises(ValueError): self.event(s, 2, "user_final", text="hi")

    def test_reply_cannot_start_during_partial(self):
        s = VoiceSession()
        self.event(s, 1, "user_partial", text="hi")
        with self.assertRaises(ValueError): self.event(s, 2, "assistant_start", reply_id="x")

    def test_session_state_is_isolated(self):
        out = replay([{"session":"a","seq":1,"type":"user_final","text":"alpha"},
                      {"session":"b","seq":1,"type":"user_final","text":"beta"}])
        self.assertEqual(out["sessions"]["a"]["turns"][0]["text"], "alpha")
        self.assertEqual(out["sessions"]["b"]["turns"][0]["text"], "beta")

    def test_invalid_event_does_not_consume_sequence(self):
        s = VoiceSession()
        with self.assertRaises(ValueError): self.event(s, 1, "user_final", text=" ")
        self.event(s, 1, "user_final", text="valid")
        self.assertEqual(s.sequence, 1)

    def test_late_end_cannot_stop_new_reply(self):
        s = VoiceSession()
        self.event(s,1,"user_final",text="first")
        self.event(s,2,"assistant_start",reply_id="old")
        self.event(s,3,"user_final",text="new request")
        self.event(s,4,"assistant_start",reply_id="new")
        self.event(s,5,"assistant_end",reply_id="old")
        self.assertEqual(s.active["id"],"new")

    def test_reply_id_reuse_is_rejected(self):
        s = VoiceSession()
        self.event(s,1,"user_final",text="first")
        self.event(s,2,"assistant_start",reply_id="once")
        self.event(s,3,"assistant_end",reply_id="once")
        self.event(s,4,"user_final",text="second")
        with self.assertRaises(ValueError): self.event(s,5,"assistant_start",reply_id="once")

    def test_close_interrupts_active_playback(self):
        s = VoiceSession()
        self.event(s,1,"user_final",text="hello")
        self.event(s,2,"assistant_start",reply_id="once")
        output=self.event(s,3,"close")
        self.assertEqual(output[0]["reason"],"session_closed")
        self.assertIsNone(s.active)

    def test_whitespace_chunk_preserves_streamed_spacing(self):
        s = VoiceSession()
        self.event(s,1,"user_final",text="hello")
        self.event(s,2,"assistant_start",reply_id="stream")
        self.event(s,3,"assistant_chunk",reply_id="stream",text="Hello")
        with self.assertRaises(ValueError):
            self.event(s,4,"assistant_chunk",reply_id="stream",text="")
        self.event(s,4,"assistant_chunk",reply_id="stream",text=" ")
        self.event(s,5,"assistant_chunk",reply_id="stream",text="there")
        self.event(s,6,"assistant_end",reply_id="stream")
        self.assertEqual(s.turns[-1]["text"],"Hello there")


if __name__ == "__main__": unittest.main()
