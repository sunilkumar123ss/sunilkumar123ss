# VoiceDesk

**A stateful voice-session core you can inspect without microphones, API keys or model downloads.**

VoiceDesk replays supplied transcript and playback events. It separates provisional text from committed user turns, interrupts assistant playback when a user starts speaking, and fences late chunks from cancelled replies. The fixture demonstrates a complete interrupted conversation.

## Run

Python 3.9+ · standard library only.

```sh
python3 main.py
python3 main.py --help
python3 main.py --input example.json
python3 -m unittest discover -s . -p 'test_main.py' -v
```

The default fixture is located relative to `main.py`; the default demo and help command work from any working directory. An explicitly supplied input path follows the caller's working directory.

## Follow the state

`user_partial` updates the preview. `user_final` commits one user turn. `assistant_start` opens a unique reply; `assistant_chunk` adds playback text; `assistant_end` commits the completed assistant turn. A user event during playback emits `cancel_playback`, records the interrupted turn and closes that reply. Late chunks or end events with an old reply ID produce `stale_reply_ignored`. `close` is terminal and cancels active playback.

Every event needs a session ID and strictly increasing integer `seq`. Invalid events do not consume a sequence number. User transcripts must contain non-whitespace text. Assistant chunks may contain whitespace alone, preserving streamed word boundaries, but empty chunks are rejected. Session state is independent. A reply can begin only after a completed user turn and while no partial transcript or active playback exists. Reply IDs cannot be reused.

The default output includes:

```json
{"type":"cancel_playback","reply_id":"r1","reason":"barge_in"}
```

The replay result contains emitted actions and final session histories. It does not expose real audio or personal information; all supplied text is synthetic.

## What the tests establish

Twelve tests cover partial replacement, normal and whitespace-only chunk assembly, barge-in, stale reply fencing, sequence validation, terminal closure, session isolation and reply-ID reuse. These validate state transitions, not speech recognition quality or end-to-end latency.

## Scope

This Python core does not implement Whisper, TTS, WebSockets, Redis, LangGraph or live audio capture. An application could translate emitted actions into those adapters, but would still need authentication, resource limits, event persistence and integration tests. Barge-in here is triggered by an explicit transcript event; acoustic activity detection and false-positive handling are outside this reference.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The `verify.yml.template` file contains an optional GitHub Actions workflow. Place it at `.github/workflows/verify.yml` to enable hosted checks; the current repository is verified locally.
