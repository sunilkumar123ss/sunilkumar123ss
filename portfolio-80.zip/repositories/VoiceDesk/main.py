#!/usr/bin/env python3
"""Replay transcript and playback events through a stateful offline voice session."""
import argparse
import json
from pathlib import Path


class VoiceSession:
    def __init__(self):
        self.sequence = -1
        self.closed = False
        self.partial = ""
        self.turns = []
        self.active = None
        self.used_replies = set()

    def _interrupt(self, reason):
        if self.active is None:
            return []
        reply = self.active
        self.turns.append({"speaker": "assistant", "text": "".join(reply["chunks"]),
                           "interrupted": True})
        self.active = None
        return [{"type": "cancel_playback", "reply_id": reply["id"], "reason": reason}]

    def apply(self, event):
        if not isinstance(event, dict):
            raise ValueError("event must be an object")
        seq = event.get("seq")
        if type(seq) is not int or seq <= self.sequence:
            raise ValueError("seq must strictly increase within a session")
        if self.closed:
            raise ValueError("session is closed")
        kind = event.get("type")
        if kind not in {"user_partial", "user_final", "assistant_start", "assistant_chunk", "assistant_end", "close"}:
            raise ValueError("unknown event type")
        if kind in {"user_partial", "user_final"}:
            if not isinstance(event.get("text"), str) or not event["text"].strip():
                raise ValueError("user transcript must be nonblank")
        if kind == "assistant_chunk":
            if not isinstance(event.get("text"), str) or not event["text"]:
                raise ValueError("assistant chunk must be a nonempty string")
        if kind.startswith("assistant_"):
            if not isinstance(event.get("reply_id"), str) or not event["reply_id"]:
                raise ValueError("reply_id is required")
        if kind == "assistant_start":
            if self.active or self.partial or not self.turns or self.turns[-1]["speaker"] != "user":
                raise ValueError("a reply needs a completed user turn and idle playback")
            if event["reply_id"] in self.used_replies:
                raise ValueError("reply_id cannot be reused")
        self.sequence = seq
        if kind in {"user_partial", "user_final"}:
            emitted = self._interrupt("barge_in")
            if kind == "user_partial":
                self.partial = event["text"]
                return emitted + [{"type": "transcript_preview", "text": self.partial}]
            self.partial = ""
            self.turns.append({"speaker": "user", "text": event["text"]})
            return emitted + [{"type": "transcript_committed", "text": event["text"]}]
        if kind == "assistant_start":
            self.active = {"id": event["reply_id"], "chunks": []}
            self.used_replies.add(event["reply_id"])
            return [{"type": "playback_started", "reply_id": event["reply_id"]}]
        if kind in {"assistant_chunk", "assistant_end"}:
            if self.active is None or self.active["id"] != event["reply_id"]:
                return [{"type": "stale_reply_ignored", "reply_id": event["reply_id"]}]
            if kind == "assistant_chunk":
                self.active["chunks"].append(event["text"])
                return [{"type": "playback_chunk", "text": event["text"]}]
            self.turns.append({"speaker": "assistant", "text": "".join(self.active["chunks"]),
                               "interrupted": False})
            self.active = None
            return [{"type": "playback_finished"}]
        emitted = self._interrupt("session_closed")
        self.partial = ""
        self.closed = True
        return emitted + [{"type": "session_closed"}]


def replay(events):
    if not isinstance(events, list):
        raise ValueError("events must be a list")
    sessions, output = {}, []
    for event in events:
        if not isinstance(event, dict) or not isinstance(event.get("session"), str) or not event["session"]:
            raise ValueError("each event needs a session id")
        session = sessions.setdefault(event["session"], VoiceSession())
        output.extend(dict(item, session=event["session"], seq=event["seq"]) for item in session.apply(event))
    return {"events": output, "sessions": {key: {"closed": value.closed, "partial": value.partial,
            "turns": value.turns, "speaking": value.active is not None} for key, value in sessions.items()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("example.json"))
    args = parser.parse_args()
    try:
        print(json.dumps(replay(json.loads(args.input.read_text())), indent=2))
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
