import unittest
from main import evaluate

PRICES = {"demo": {"input": "2", "cached_input": "0.5", "output": "4"}}


class CostTests(unittest.TestCase):
    def test_cached_tokens_are_not_double_counted(self):
        result = evaluate(PRICES, [{"request_id": "x", "model": "demo", "input_tokens": 1000,
                                   "cached_input_tokens": 200, "output_tokens": 100}], "0.0021")
        self.assertEqual(result["total_cost"], "0.0021")
        self.assertFalse(result["over_budget"])
        self.assertEqual(result["remaining"], "0.0000")

    def test_empty_usage(self):
        self.assertEqual(evaluate(PRICES, [], 0)["total_cost"], "0")

    def test_invalid_counts_and_unknown_model(self):
        for event in [{"request_id": "x", "model": "other"}, {"request_id": "x", "model": "demo", "input_tokens": -1},
                      {"request_id": "x", "model": "demo", "cached_input_tokens": 1}]:
            with self.subTest(event=event), self.assertRaises(ValueError):
                evaluate(PRICES, [event], 1)

    def test_duplicate_event_and_nan_budget(self):
        event = {"request_id": "x", "model": "demo"}
        with self.assertRaises(ValueError):
            evaluate(PRICES, [event, event], 1)
        with self.assertRaises(ValueError):
            evaluate(PRICES, [], "NaN")


if __name__ == "__main__":
    unittest.main()
