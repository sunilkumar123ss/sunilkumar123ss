"""Exact-decimal token cost accounting using caller-supplied example prices."""
import argparse
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys


def money(value):
    if isinstance(value, bool):
        raise ValueError("prices and budgets cannot be booleans")
    try:
        result = Decimal(str(value))
    except InvalidOperation as error:
        raise ValueError("invalid price or budget") from error
    if not result.is_finite() or result < 0:
        raise ValueError("prices and budgets must be nonnegative and finite")
    return result


def evaluate(prices, events, budget):
    if not isinstance(prices, dict) or not prices or not isinstance(events, list):
        raise ValueError("prices must be a nonempty mapping and events a list")
    parsed = {name: {key: money(row[key]) for key in ("input", "cached_input", "output")}
              for name, row in prices.items()}
    limit, total, seen, per_model, rows = money(budget), Decimal(0), set(), {}, []
    for event in events:
        request_id, model = event["request_id"], event["model"]
        if not isinstance(request_id, str) or not request_id or request_id in seen:
            raise ValueError("request_id must be a unique nonempty string")
        seen.add(request_id)
        if model not in parsed:
            raise ValueError(f"unknown model: {model}")
        tokens = {key: event.get(key, 0) for key in ("input_tokens", "cached_input_tokens", "output_tokens")}
        if any(type(n) is not int or n < 0 for n in tokens.values()):
            raise ValueError("token counts must be nonnegative integers")
        if tokens["cached_input_tokens"] > tokens["input_tokens"]:
            raise ValueError("cached input is a subset of total input")
        price = parsed[model]
        cost = ((tokens["input_tokens"] - tokens["cached_input_tokens"]) * price["input"] +
                tokens["cached_input_tokens"] * price["cached_input"] + tokens["output_tokens"] * price["output"]) / 1_000_000
        total += cost
        per_model[model] = per_model.get(model, Decimal(0)) + cost
        rows.append({"request_id": request_id, "cost": str(cost)})
    return {"currency": "caller_defined", "requests": rows, "total_cost": str(total),
            "per_model": {key: str(value) for key, value in per_model.items()},
            "budget": str(limit), "remaining": str(limit - total), "over_budget": total > limit}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    args = parser.parse_args()
    try:
        input_path = Path(args.input)
        if not input_path.is_absolute():
            input_path = Path(__file__).resolve().parent / input_path
        with input_path.open(encoding="utf-8") as handle:
            data = json.load(handle)
        print(json.dumps(evaluate(data["prices_per_million"], data["events"], data["budget"]), indent=2))
        return 0
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(f"Invalid cost ledger: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
