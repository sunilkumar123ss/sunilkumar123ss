# Token cost accounting

An offline cost ledger for recorded token counts. Prices in the example are invented configuration values, not current provider prices. No inference or billing API is contacted.

~~~sh
python3 main.py --input example.json
python3 -m unittest -v
~~~

Supply input, cached-input, and output prices per million tokens in one currency. Total input tokens include cached tokens; the calculator charges each input token once. Decimal arithmetic and string output preserve exact decimal amounts. Unique request IDs guard against duplicate billing rows. A total equal to the budget is allowed; overspending yields a negative remaining amount.

The result excludes taxes, tool fees, storage, minimum charges, retries missing from the ledger, and provider-specific billing rules. Verify actual tariffs and token measurements before financial use.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
