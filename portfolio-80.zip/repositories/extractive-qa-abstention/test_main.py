import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
answer = _main.answer

class QATests(unittest.TestCase):
    def test_answer_is_exact_source_sentence(self):
        text = "Audit logs are stored in an internal bucket. Snapshots last seven days."
        result = answer("Where are audit logs stored?", {"ops":text})
        self.assertFalse(result["abstained"])
        self.assertIn(result["answer"], text)
        self.assertEqual(result["source_id"], "ops")
    def test_unknown_and_stopword_only_abstain(self):
        self.assertTrue(answer("What is the moon temperature?", {"s":"Audit logs exist."})["abstained"])
        self.assertTrue(answer("What is it?", {"s":"It is."})["abstained"])
    def test_threshold_controls_weak_matches(self):
        self.assertTrue(answer("audio latency", {"s":"Audio streams."}, 0.9)["abstained"])
        self.assertFalse(answer("audio latency", {"s":"Audio streams."}, 0.5)["abstained"])
    def test_invalid_threshold(self):
        with self.assertRaises(ValueError): answer("x", {}, 2)

if __name__ == "__main__": unittest.main()
