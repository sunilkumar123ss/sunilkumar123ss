# Bounded DTMF IVR Router

**Demo/starter · Python standard library only.**

Route supplied keypad symbols through a small IVR with retry limits, timeouts and human handoff.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input is an ordered JSON list of `{at_ms, digit?}`; omit the digit for a timer tick. At the main menu, 1 selects billing and 2 selects technical support. Submenu 1/2 select an intent; * returns to main, 0 routes to a human and # ends. Invalid digits and timeouts share a retry budget. Closed sessions reject further events.

## Limits and optional provider boundary

This is a state machine, not an audio-frequency DTMF detector. Events drive timeout checks; no background timers or calls run. The router returns terminal actions as data and does not contact a queue.

A telephony adapter could supply detected symbols and execute the returned actions. No such adapter is connected.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
