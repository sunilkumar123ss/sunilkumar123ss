"""Route externally detected DTMF symbols through a bounded IVR menu."""
import argparse
import json
import math
from pathlib import Path

class Router:

    def __init__(self, timeout_ms=3000, max_retries=2):
        if isinstance(timeout_ms, bool) or not isinstance(timeout_ms, (int, float)) or (not math.isfinite(timeout_ms)) or (timeout_ms <= 0):
            raise ValueError('timeout_ms must be finite and positive')
        if isinstance(max_retries, bool) or not isinstance(max_retries, int) or max_retries < 1:
            raise ValueError('max_retries must be positive integer')
        self.timeout_ms = timeout_ms
        self.max_retries = max_retries
        self.state = 'main'
        self.retries = 0
        self.last_input = 0
        self.last_event = -1

    def handle(self, event):
        if not isinstance(event, dict):
            raise ValueError('Event must be object')
        now = event.get('at_ms')
        digit = event.get('digit')
        if isinstance(now, bool) or not isinstance(now, (int, float)) or (not math.isfinite(now)) or (now < 0) or (now < self.last_event):
            raise ValueError('Timestamps must be finite and ordered')
        if digit is not None and (not isinstance(digit, str) or len(digit) != 1 or digit not in '0123456789*#ABCD'):
            raise ValueError('Invalid DTMF symbol')
        if self.state == 'closed':
            raise ValueError('Session already closed')
        self.last_event = now
        actions = []
        if now - self.last_input >= self.timeout_ms:
            self.retries += 1
            self.last_input = now
            if self.retries >= self.max_retries:
                self.state = 'closed'
                return [{'action': 'end', 'reason': 'timeout_limit'}]
            actions.append({'action': 'reprompt', 'reason': 'timeout', 'menu': self.state})
        if digit is None:
            return actions
        self.last_input = now
        if digit == '#':
            self.state = 'closed'
            return actions + [{'action': 'end', 'reason': 'caller_request'}]
        if digit == '*':
            self.state = 'main'
            self.retries = 0
            return actions + [{'action': 'menu', 'name': 'main'}]
        if digit == '0':
            self.state = 'closed'
            return actions + [{'action': 'transfer', 'destination': 'human_queue'}]
        routes = {'main': {'1': 'billing', '2': 'technical'}, 'billing': {'1': 'invoice_status', '2': 'payment_help'}, 'technical': {'1': 'connectivity_help', '2': 'device_help'}}
        target = routes[self.state].get(digit)
        if target is None:
            self.retries += 1
            if self.retries >= self.max_retries:
                self.state = 'closed'
                return actions + [{'action': 'transfer', 'destination': 'human_queue', 'reason': 'invalid_limit'}]
            return actions + [{'action': 'reprompt', 'reason': 'invalid_digit', 'menu': self.state}]
        self.retries = 0
        if self.state == 'main':
            self.state = target
            return actions + [{'action': 'menu', 'name': target}]
        self.state = 'closed'
        return actions + [{'action': 'route', 'intent': target}]

def replay(events):
    if not isinstance(events, list):
        raise ValueError('Events must be a list')
    router = Router()
    actions = []
    for event in events:
        actions.extend(router.handle(event))
    return {'actions': actions, 'state': router.state}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON [{at_ms,digit?},...] ; omitted digit is timeout tick')
    args = parser.parse_args()
    try:
        events = json.loads(args.input.read_text()) if args.input else [{'at_ms': 100, 'digit': '1'}, {'at_ms': 300, 'digit': '2'}]
        print(json.dumps({'boundary': 'Detected keypad symbols supplied externally; no tone decoder or telephony calls', **replay(events)}, indent=2))
    except (ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
