import unittest
try:
    from .main import Router, replay
except ImportError:
    from main import Router, replay

class DtmfTests(unittest.TestCase):

    def test_nested_route(self):
        r = replay([{'at_ms': 1, 'digit': '2'}, {'at_ms': 2, 'digit': '1'}])
        self.assertEqual(r['actions'][-1], {'action': 'route', 'intent': 'connectivity_help'})
        self.assertEqual(r['state'], 'closed')

    def test_back_and_human(self):
        r = replay([{'at_ms': 1, 'digit': '1'}, {'at_ms': 2, 'digit': '*'}, {'at_ms': 3, 'digit': '0'}])
        self.assertEqual(r['actions'][-1]['destination'], 'human_queue')

    def test_retry_limit(self):
        r = replay([{'at_ms': 1, 'digit': '9'}, {'at_ms': 2, 'digit': '9'}])
        self.assertEqual(r['actions'][-1]['reason'], 'invalid_limit')

    def test_timeout(self):
        r = Router(timeout_ms=100)
        self.assertEqual(r.handle({'at_ms': 100})[0]['reason'], 'timeout')
        self.assertEqual(r.handle({'at_ms': 200})[0]['reason'], 'timeout_limit')

    def test_invalid_closed_or_outoforder(self):
        r = Router()
        with self.assertRaises(ValueError):
            r.handle({'at_ms': 0, 'digit': '12'})
        r.handle({'at_ms': 5, 'digit': '#'})
        with self.assertRaises(ValueError):
            r.handle({'at_ms': 6})
        with self.assertRaises(ValueError):
            Router().handle({'at_ms': float('nan')})
if __name__ == '__main__':
    unittest.main()
