"""Inspect normalized PCM signal levels; does not judge speech intelligibility."""
import argparse
import json
import math
from pathlib import Path

def analyze(samples, sample_rate, silence_threshold=0.01):
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, int) or sample_rate <= 0:
        raise ValueError('sample_rate must be positive integer')
    if isinstance(silence_threshold, bool) or not isinstance(silence_threshold, (int, float)) or (not math.isfinite(silence_threshold)) or (not 0 <= silence_threshold <= 1):
        raise ValueError('silence_threshold must be in [0,1]')
    if not isinstance(samples, list) or not samples:
        raise ValueError('Provide a nonempty sample list')
    if any((isinstance(x, bool) or not isinstance(x, (int, float)) or (not math.isfinite(x)) or (abs(x) > 1) for x in samples)):
        raise ValueError('Samples must be normalized finite numbers')
    count = len(samples)
    rms = math.sqrt(sum((x * x for x in samples)) / count)
    peak = max((abs(x) for x in samples))
    crossings = sum((1 for (a, b) in zip(samples, samples[1:]) if a < 0 <= b or b < 0 <= a))
    return {'samples': count, 'duration_seconds': count / sample_rate, 'rms': rms, 'rms_dbfs': 20 * math.log10(rms) if rms else None, 'peak': peak, 'dc_offset': sum(samples) / count, 'clipped_fraction': sum((abs(x) >= 32767 / 32768 for x in samples)) / count, 'quiet_fraction': sum((abs(x) < silence_threshold for x in samples)) / count, 'zero_crossing_rate': crossings / (count - 1) if count > 1 else 0, 'crest_factor': peak / rms if rms else None}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON {samples:[...], sample_rate:int}')
    args = parser.parse_args()
    try:
        p = json.loads(args.input.read_text()) if args.input else {'samples': [0] * 100 + [0.5, -0.5] * 200 + [1, -1] * 10, 'sample_rate': 8000}
        if not isinstance(p, dict):
            raise ValueError('Input must be an object')
        print(json.dumps({'source': 'synthetic fixture' if not args.input else 'input samples', 'quality': analyze(p['samples'], p['sample_rate']), 'note': 'These signal statistics are not a speech-recognition or perceptual-quality score.'}, indent=2, allow_nan=False))
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
