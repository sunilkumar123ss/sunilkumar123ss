import math
import unittest
try:
    from .main import analyze
except ImportError:
    from main import analyze

class QualityTests(unittest.TestCase):

    def test_silence(self):
        result = analyze([0] * 10, 1000)
        self.assertEqual(result['quiet_fraction'], 1)
        self.assertIsNone(result['rms_dbfs'])
        self.assertIsNone(result['crest_factor'])

    def test_known_wave(self):
        result = analyze([0.5, -0.5, 0.5, -0.5], 4)
        self.assertEqual(result['rms'], 0.5)
        self.assertAlmostEqual(result['rms_dbfs'], -6.020599913)
        self.assertEqual(result['zero_crossing_rate'], 1)
        self.assertEqual(result['dc_offset'], 0)

    def test_clipping_dc(self):
        result = analyze([1, 1, 0, 0], 4)
        self.assertEqual(result['clipped_fraction'], 0.5)
        self.assertEqual(result['dc_offset'], 0.5)

    def test_single(self):
        self.assertEqual(analyze([0.2], 1)['zero_crossing_rate'], 0)

    def test_invalid(self):
        for samples in [[], [float('inf')], [2], [True]]:
            with self.assertRaises(ValueError):
                analyze(samples, 8000)
        with self.assertRaises(ValueError):
            analyze([0], 0)
if __name__ == '__main__':
    unittest.main()
