# Audio Signal Diagnostics

**Demo/starter · Python standard library only.**

Measure RMS, dBFS, peak, DC offset, clipping, quiet fraction, zero crossings and crest factor.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input JSON contains a nonempty normalized `samples` list and a positive integer `sample_rate`. Output is JSON signal statistics. All-zero input returns null for dBFS and crest factor. Clipping flags magnitudes at or above 32767/32768.

## Limits and optional provider boundary

These arithmetic descriptors are not a perceptual quality score, intelligibility test, ASR accuracy result or proof of speech. Quiet detection is a simple threshold. The fixture combines synthetic silence, alternating values and clipped peaks.

A capture or WAV decoder adapter can supply samples. No microphone access, model or cloud upload is used.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
