"""Energy-gated activity intervals; this is not a trained speech detector."""
import argparse
import json
import math
from pathlib import Path

def detect(samples, sample_rate, frame_ms=20, threshold_db=-35, min_voice_ms=40, hangover_ms=40):
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, int) or sample_rate <= 0:
        raise ValueError('sample_rate must be a positive integer')
    for (name, value) in (('frame_ms', frame_ms), ('threshold_db', threshold_db), ('min_voice_ms', min_voice_ms), ('hangover_ms', hangover_ms)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or (not math.isfinite(value)):
            raise ValueError(name + ' must be finite')
    if frame_ms <= 0 or min_voice_ms <= 0 or hangover_ms < 0 or (not -120 <= threshold_db <= 0):
        raise ValueError('Invalid VAD configuration')
    if not isinstance(samples, list) or any((isinstance(x, bool) or not isinstance(x, (int, float)) or (not math.isfinite(x)) or (abs(x) > 1) for x in samples)):
        raise ValueError('samples must be normalized finite numbers in [-1,1]')
    size = int(sample_rate * frame_ms / 1000)
    if size < 1:
        raise ValueError('frame_ms is shorter than one sample')
    required = max(1, math.ceil(min_voice_ms * sample_rate / 1000))
    tail = math.ceil(hangover_ms / (size * 1000 / sample_rate))
    threshold = 10 ** (threshold_db / 20)
    (runs, active, candidate, streak, quiet) = ([], None, None, 0, 0)
    for start in range(0, len(samples), size):
        frame = samples[start:start + size]
        end = start + len(frame)
        energetic = math.sqrt(sum((x * x for x in frame)) / len(frame)) >= threshold
        if energetic:
            if streak == 0:
                candidate = start
            streak += len(frame)
            quiet = 0
            if active is None and streak >= required:
                active = candidate
        else:
            streak = 0
            candidate = None
            if active is not None:
                quiet += 1
                if quiet >= max(1, tail):
                    stop = start if tail == 0 else end
                    runs.append({'start_sample': active, 'end_sample': stop})
                    active = None
                    quiet = 0
    if active is not None:
        runs.append({'start_sample': active, 'end_sample': len(samples)})
    return runs

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON {samples: [...], sample_rate: integer}')
    parser.add_argument('--threshold-db', type=float, default=-35)
    args = parser.parse_args()
    try:
        payload = json.loads(args.input.read_text()) if args.input else {'sample_rate': 1000, 'samples': [0.0] * 60 + [0.25] * 100 + [0.0] * 80}
        if not isinstance(payload, dict):
            raise ValueError('Input must be an object')
        result = detect(payload['samples'], payload['sample_rate'], threshold_db=args.threshold_db)
        print(json.dumps({'method': 'RMS energy threshold, no speech recognition', 'intervals': result}, indent=2))
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
