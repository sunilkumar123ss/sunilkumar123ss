# Energy Activity Detector

**Demo/starter · Python standard library only.**

Locate sustained high-energy intervals with minimum onset duration and a silence hangover.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json --threshold-db -20
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input JSON contains `samples`, a list of finite normalized numbers in [-1, 1], and a positive integer `sample_rate`. The `detect` function also accepts frame, onset and hangover durations. RMS energy is compared with a dBFS threshold. Returned intervals use sample indices and include the configured hangover. A partial frame cannot falsely satisfy the minimum onset duration.

## Limits and optional provider boundary

Energy does not establish speech: music and noise may trigger the detector, while quiet speech may be missed. This is not a trained or adaptive VAD and has no claimed accuracy. The fixture is silence and constant-amplitude synthetic samples.

A capture or decoder adapter can supply normalized samples; an ASR adapter could consume the intervals. Neither capture nor inference is included.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
