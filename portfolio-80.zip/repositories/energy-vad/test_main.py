import unittest
try:
    from .main import detect
except ImportError:
    from main import detect

class VadTests(unittest.TestCase):

    def test_onset_and_hangover(self):
        self.assertEqual(detect([0.0] * 10 + [0.5] * 30 + [0.0] * 30, 1000, 10, -20, 20, 20), [{'start_sample': 10, 'end_sample': 60}])

    def test_short_burst_is_rejected(self):
        self.assertEqual(detect([0.5] * 10 + [0.0] * 30, 1000, 10, -20, 20, 0), [])

    def test_no_hangover(self):
        self.assertEqual(detect([0.5] * 20 + [0.0] * 20, 1000, 10, -20, 20, 0), [{'start_sample': 0, 'end_sample': 20}])

    def test_partial_frame_cannot_meet_minimum_duration(self):
        self.assertEqual(detect([0.5] * 11, 1000, 10, -20, 20, 0), [])

    def test_flush_and_empty(self):
        self.assertEqual(detect([0.5] * 25, 1000, 10, -20, 20, 20)[0]['end_sample'], 25)
        self.assertEqual(detect([], 1000), [])

    def test_invalid(self):
        for (samples, rate) in [([float('nan')], 1000), ([2], 1000), ([True], 1000), ([0], 0)]:
            with self.assertRaises(ValueError):
                detect(samples, rate)
        with self.assertRaises(ValueError):
            detect([], 1000, frame_ms=0.1)
if __name__ == '__main__':
    unittest.main()
