import json
from pathlib import Path
import tempfile
import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
run = _main.run

class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/"state.json"
        self.text="one two three four"
    def test_resume_and_completed_idempotence(self):
        self.assertEqual(run(self.text,self.path,1)["stage"],"validated")
        self.assertEqual(run(self.text,self.path,1)["stage"],"previewed")
        completed=run(self.text,self.path,1)
        self.assertEqual(completed["stage"],"complete")
        self.assertEqual(run(self.text,self.path,5),completed)
        self.assertEqual(json.loads(self.path.read_text()),completed)
    def test_changed_document_rejected(self):
        run(self.text,self.path,1)
        with self.assertRaises(ValueError):run(self.text+" changed",self.path)
    def test_corrupt_checkpoint_rejected(self):
        state=run(self.text,self.path,1);state["word_count"]=99
        self.path.write_text(json.dumps(state))
        with self.assertRaises(ValueError):run(self.text,self.path)
    def test_boolean_version_and_count_are_not_integers(self):
        state = run("one", self.path, 1)
        for key in ["version", "word_count"]:
            modified = dict(state); modified[key] = True
            self.path.write_text(json.dumps(modified))
            with self.assertRaises(ValueError): run("one", self.path)
    def test_empty_document_and_negative_steps(self):
        with self.assertRaises(ValueError):run(" ",self.path)
        with self.assertRaises(ValueError):run(self.text,self.path,-1)

if __name__ == "__main__":unittest.main()
