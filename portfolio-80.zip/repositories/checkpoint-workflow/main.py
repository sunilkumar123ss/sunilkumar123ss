"""Restart-safe local workflow checkpoints for deterministic processing."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile

STAGES = ("received", "validated", "previewed", "complete")

def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()

def initial(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("document must not be empty")
    return {"version":1, "document_sha256":digest(text), "stage":"received"}

def validate(state, text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("document must not be empty")
    if not isinstance(state, dict) or type(state.get("version")) is not int or state.get("version") != 1 or state.get("stage") not in STAGES:
        raise ValueError("invalid checkpoint format")
    if state.get("document_sha256") != digest(text):
        raise ValueError("checkpoint belongs to different document content")
    stage = STAGES.index(state["stage"])
    expected = {"version", "document_sha256", "stage"}
    if stage >= 1:
        expected.add("word_count")
        if type(state.get("word_count")) is not int or state.get("word_count") != len(text.split()):
            raise ValueError("checkpoint word count is inconsistent")
    if stage >= 2:
        expected.add("preview")
        if state.get("preview") != " ".join(text.split()[:20]):
            raise ValueError("checkpoint preview is inconsistent")
    if set(state) != expected:
        raise ValueError("unexpected or missing checkpoint fields")


def advance(state, text):
    validate(state, text)
    next_state = dict(state)
    if state["stage"] == "received":
        next_state.update(stage="validated", word_count=len(text.split()))
    elif state["stage"] == "validated":
        next_state.update(stage="previewed", preview=" ".join(text.split()[:20]))
    elif state["stage"] == "previewed":
        next_state["stage"] = "complete"
    return next_state


def save_atomic(path, state):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix=".checkpoint-", dir=path.parent)
    try:
        with os.fdopen(handle, "w") as stream:
            json.dump(state, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run(text, path, steps=3):
    if isinstance(steps,bool) or not isinstance(steps,int) or steps < 0:
        raise ValueError("steps must be a nonnegative integer")
    path = Path(path)
    state = json.loads(path.read_text()) if path.exists() else initial(text)
    validate(state, text)
    for _ in range(steps):
        state = advance(state, text)
        save_atomic(path, state)
        if state["stage"] == "complete":
            break
    return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--document", type=Path, default=Path(__file__).with_name("document.txt"))
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--steps", type=int, default=3)
    args = parser.parse_args()
    try:
        text = args.document.read_text()
        if args.checkpoint:
            result = run(text, args.checkpoint, args.steps)
        else:
            with tempfile.TemporaryDirectory() as folder:
                result = run(text, Path(folder)/"checkpoint.json", args.steps)
    except (ValueError,OSError,TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps(result,indent=2))

if __name__ == "__main__": main()
