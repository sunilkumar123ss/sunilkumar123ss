# Resumable checkpoint workflow

Runnable educational demo/starter with synthetic examples.

Runs a deterministic document-processing state machine: received → validated → previewed → complete. It persists checkpoints with atomic replacement and validates the document digest and stage outputs on resume. A preview is the first 20 whitespace-separated words, not an AI summary. Use `--checkpoint checkpoint.json --steps 1` repeatedly to exercise resumption. This local demo has no concurrent-writer locking and performs no external side effects.

## Run

Python 3.10+; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

No network requests, credentials, or paid services are used. Any model/provider integration would be a separate adapter. Read `main.py` for the public functions and `test_main.py` for success/failure invariants. Fixture content is synthetic.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
