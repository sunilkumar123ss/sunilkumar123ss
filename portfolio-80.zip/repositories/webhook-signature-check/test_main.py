import unittest
from main import sign, verify


class WebhookSignatureTests(unittest.TestCase):
    def setUp(self):
        self.body = b'{"synthetic":true}'
        self.secret = b"test-key-only"
        self.header = sign(self.body, self.secret, 1000)

    def test_valid_and_wrong_secret(self):
        self.assertTrue(verify(self.body, self.header, [self.secret], 1001))
        self.assertFalse(verify(self.body, self.header, [b"wrong-test-key"], 1001))

    def test_exact_raw_body_matters(self):
        self.assertFalse(verify(b'{ "synthetic": true }', self.header, [self.secret], 1000))

    def test_expiry_and_future_timestamps(self):
        self.assertFalse(verify(self.body, self.header, [self.secret], 1301))
        self.assertFalse(verify(self.body, self.header, [self.secret], 699))

    def test_tolerance_boundary_inclusive(self):
        self.assertTrue(verify(self.body, self.header, [self.secret], 1300))
        self.assertTrue(verify(self.body, self.header, [self.secret], 700))

    def test_key_rotation_and_multiple_signatures(self):
        self.assertTrue(verify(self.body, self.header, [b"old-key", self.secret], 1000))
        other = sign(self.body, b"other-key", 1000).split(",", 1)[1]
        self.assertTrue(verify(self.body, self.header + "," + other, [self.secret], 1000))

    def test_malformed_headers(self):
        for header in ("", "t=1000", self.header + ",t=1000", "t=01000,v1=" + "a"*64,
                       "t=1000,v1=xyz", self.header + ",unexpected=value"):
            with self.subTest(header=header):
                self.assertFalse(verify(self.body, header, [self.secret], 1000))

    def test_timestamp_is_signed(self):
        self.assertFalse(verify(self.body, self.header.replace("t=1000", "t=1001"), [self.secret], 1001))

    def test_invalid_configuration(self):
        with self.assertRaises(ValueError): verify(self.body, self.header, [], 1000)
        with self.assertRaises(ValueError): verify(self.body, self.header, [self.secret], 1000, -1)
        with self.assertRaises(TypeError): sign("text", self.secret, 1000)


if __name__ == '__main__':
    unittest.main()
