# Webhook Signature Check

Validate raw payload integrity and a bounded timestamp window using HMAC.

All bundled examples use synthetic data.

## Run

Requires Python 3.9 or later; no third-party packages or network access are needed.

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

Run these commands from this repository's directory. The demo can also be launched from any directory by passing the absolute path to `main.py`.

## How it works

The custom demonstration format signs `ASCII(timestamp) + b"." + raw_body` with HMAC-SHA256. A header contains one `t=` timestamp and one or more lowercase hexadecimal `v1=` signatures. Verification rejects malformed fields and timestamps outside the inclusive tolerance window, then checks candidates with `hmac.compare_digest`. Multiple configured keys support a rotation overlap.

The demo secret is explicitly synthetic. Verification is O(body bytes × configured keys), plus signature comparisons. Header length is capped at 2048 characters.

## Reuse

```python
from main import sign, verify

secret = b"synthetic-example-key"
body = b'{"event_id":"demo-001"}'
header = sign(body, secret, timestamp=1000)
assert verify(body, header, [secret], now=1010)
assert not verify(body + b" ", header, [secret], now=1010)
assert not verify(body, header, [secret], now=1301)
```

## Demo behavior

The default output shows an accepted original body, a rejected body with one extra byte, and a rejected expired signature. No secret is loaded from the environment and no request is sent.

## Boundaries

This is a custom learning protocol, not an implementation of a particular provider's webhook contract. Timestamp checks limit replay age but do not prevent duplicates within the window; use a durable event-ID store when that matters. Supply exact raw bytes before JSON parsing, configure clock/tolerance policy, and manage real keys separately. HTTP transport, body-size limits, authorization, and secret storage are outside this lab. There is no claim of a security audit.

## Verification

`test_main.py` exercises boundary conditions, invalid inputs, and meaningful behavior specific to this implementation. The default demo is deterministic and completes without external services. See the collection's verification report for the recorded run; run the commands above to verify this repository independently.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
