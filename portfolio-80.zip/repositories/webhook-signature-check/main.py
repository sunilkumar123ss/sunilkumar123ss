"""Verify a timestamped HMAC-SHA256 signature over the exact raw webhook bytes."""
import argparse
import hashlib
import hmac
import json
import re


SYNTHETIC_SECRET = b"synthetic-demo-secret-not-for-real-webhooks"


def _validate_secret(secret):
    if not isinstance(secret, bytes) or not secret:
        raise ValueError("secret must be nonempty bytes")


def _validate_time(value, name):
    if type(value) is not int or value < 0:
        raise ValueError(name + " must be a nonnegative integer")


def _digest(body, secret, timestamp):
    message = str(timestamp).encode("ascii") + b"." + body
    return hmac.new(secret, message, hashlib.sha256).hexdigest()


def sign(body, secret, timestamp):
    if not isinstance(body, bytes):
        raise TypeError("body must be bytes")
    _validate_secret(secret)
    _validate_time(timestamp, "timestamp")
    return "t={},v1={}".format(timestamp, _digest(body, secret, timestamp))


def verify(body, header, secrets, now, tolerance_seconds=300):
    if not isinstance(body, bytes):
        raise TypeError("body must be bytes")
    _validate_time(now, "now")
    _validate_time(tolerance_seconds, "tolerance_seconds")
    if isinstance(secrets, (bytes, str)):
        raise ValueError("secrets must be a nonempty collection of byte keys")
    secrets = tuple(secrets)
    if not secrets:
        raise ValueError("at least one secret is required")
    for secret in secrets:
        _validate_secret(secret)
    if not isinstance(header, str) or len(header) > 2048:
        return False
    timestamps, signatures = [], []
    for field in header.split(","):
        name, separator, value = field.strip().partition("=")
        if not separator:
            return False
        if name == "t":
            if not re.fullmatch(r"0|[1-9][0-9]{0,19}", value):
                return False
            timestamps.append(int(value))
        elif name == "v1":
            if not re.fullmatch(r"[0-9a-f]{64}", value):
                return False
            signatures.append(value)
        else:
            return False
    if len(timestamps) != 1 or not signatures:
        return False
    timestamp = timestamps[0]
    if abs(now - timestamp) > tolerance_seconds:
        return False
    matched = False
    for secret in secrets:
        expected = _digest(body, secret, timestamp)
        for signature in signatures:
            matched = hmac.compare_digest(expected, signature) or matched
    return matched


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    body = b'{"event_id":"synthetic-001","type":"order.created"}'
    timestamp = 1_700_000_000
    header = sign(body, SYNTHETIC_SECRET, timestamp)
    print(json.dumps({"synthetic_header": header,
                      "original_valid": verify(body, header, [SYNTHETIC_SECRET], timestamp + 10),
                      "tampered_valid": verify(body + b" ", header, [SYNTHETIC_SECRET], timestamp + 10),
                      "expired_valid": verify(body, header, [SYNTHETIC_SECRET], timestamp + 301)}, indent=2))


if __name__ == "__main__":
    main()
