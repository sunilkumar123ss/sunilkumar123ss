# Classification metrics

An offline Python standard-library evaluator for existing multiclass predictions. It does not train or call a model. The supplied labels are synthetic support-ticket categories.

~~~sh
python3 main.py --input example.json
python3 -m unittest -v
~~~

The report contains a true-label-by-predicted-label confusion matrix, accuracy, per-class precision/recall/F1, macro F1, and support-weighted F1. Labels are the union of actual and predicted classes; undefined precision or recall is zero. Prediction-only classes therefore contribute zero to macro F1 and have zero weight in weighted F1. Inputs must be equally sized, nonempty lists of nonempty strings.

Use the confusion matrix to identify asymmetric routing mistakes. These metrics describe only the provided evaluation set and do not establish production performance or fairness.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
