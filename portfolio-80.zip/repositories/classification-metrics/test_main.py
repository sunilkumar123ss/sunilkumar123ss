import unittest
from main import evaluate


class ClassificationTests(unittest.TestCase):
    def test_confusion_and_f1(self):
        result = evaluate(["a", "a", "b", "b"], ["a", "b", "b", "b"])
        self.assertEqual(result["confusion_matrix"]["a"]["b"], 1)
        self.assertEqual(result["accuracy"], 0.75)
        self.assertAlmostEqual(result["per_label"]["b"]["f1"], 0.8)
        self.assertAlmostEqual(result["macro_f1"], (2 / 3 + 0.8) / 2)

    def test_prediction_only_label_has_zero_support(self):
        result = evaluate(["yes"], ["unknown"])
        self.assertEqual(result["per_label"]["unknown"]["support"], 0)
        self.assertEqual(result["weighted_f1"], 0)

    def test_perfect_single_class(self):
        self.assertEqual(evaluate(["a"], ["a"])["macro_f1"], 1)

    def test_invalid_inputs(self):
        for actual, predicted in [([], []), (["a"], []), ([None], ["a"]), ("a", ["a"])]:
            with self.subTest(actual=actual), self.assertRaises(ValueError):
                evaluate(actual, predicted)


if __name__ == "__main__":
    unittest.main()
