"""Multiclass evaluation with explicit zero-division behavior."""
import argparse
import json
from pathlib import Path
import sys


def evaluate(actual, predicted):
    if not isinstance(actual, list) or not isinstance(predicted, list):
        raise ValueError("actual and predicted must be lists")
    if not actual or len(actual) != len(predicted):
        raise ValueError("nonempty actual and predicted lists must have equal length")
    if any(not isinstance(x, str) or not x for x in actual + predicted):
        raise ValueError("labels must be nonempty strings")
    labels = sorted(set(actual + predicted))
    matrix = {a: {p: 0 for p in labels} for a in labels}
    for a, p in zip(actual, predicted):
        matrix[a][p] += 1
    per_label = {}
    for label in labels:
        tp = matrix[label][label]
        support = sum(matrix[label].values())
        selected = sum(matrix[row][label] for row in labels)
        precision = tp / selected if selected else 0.0
        recall = tp / support if support else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        per_label[label] = dict(precision=precision, recall=recall, f1=f1, support=support)
    return {
        "samples": len(actual), "labels": labels, "confusion_matrix": matrix,
        "accuracy": sum(matrix[x][x] for x in labels) / len(actual),
        "macro_f1": sum(v["f1"] for v in per_label.values()) / len(labels),
        "weighted_f1": sum(v["f1"] * v["support"] for v in per_label.values()) / len(actual),
        "per_label": per_label,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="JSON with actual and predicted arrays")
    args = parser.parse_args()
    try:
        input_path = Path(args.input)
        if not input_path.is_absolute():
            input_path = Path(__file__).resolve().parent / input_path
        with input_path.open(encoding="utf-8") as handle:
            data = json.load(handle)
        print(json.dumps(evaluate(data["actual"], data["predicted"]), indent=2, allow_nan=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(f"Invalid evaluation: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
