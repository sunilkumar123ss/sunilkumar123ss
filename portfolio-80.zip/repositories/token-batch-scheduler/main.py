"""FIFO microbatch simulation with token, item, and maximum-wait limits."""
import argparse
import json
from pathlib import Path
import math
import sys


def positive_int(value, name):
    if type(value) is not int or value < 1:
        raise ValueError(f"{name} must be a positive integer")


def schedule(requests, max_tokens, max_items, max_wait_ms):
    positive_int(max_tokens, "max_tokens")
    positive_int(max_items, "max_items")
    if type(max_wait_ms) not in (int, float) or not math.isfinite(max_wait_ms) or max_wait_ms < 0:
        raise ValueError("max_wait_ms must be finite and nonnegative")
    if not isinstance(requests, list):
        raise ValueError("requests must be a list")
    seen = set()
    for request in requests:
        if not isinstance(request["id"], str) or not request["id"] or request["id"] in seen:
            raise ValueError("IDs must be unique nonempty strings")
        seen.add(request["id"])
        positive_int(request["tokens"], "tokens")
        if request["tokens"] > max_tokens:
            raise ValueError("one request exceeds the batch token capacity")
        arrival = request["arrival_ms"]
        if type(arrival) not in (int, float) or not math.isfinite(arrival) or arrival < 0:
            raise ValueError("arrival_ms must be finite and nonnegative")
    ordered = sorted(requests, key=lambda r: r["arrival_ms"])
    batches, pending, used, deadline = [], [], 0, None

    def flush(at):
        nonlocal pending, used, deadline
        batches.append({"dispatch_ms": at, "request_ids": [r["id"] for r in pending], "tokens": used,
                        "wait_ms": {r["id"]: at - r["arrival_ms"] for r in pending}})
        pending, used, deadline = [], 0, None

    for request in ordered:
        arrival = request["arrival_ms"]
        if pending and arrival > deadline:
            flush(deadline)
        if pending and used + request["tokens"] > max_tokens:
            flush(arrival)
        if not pending:
            deadline = arrival + max_wait_ms
            if not math.isfinite(deadline):
                raise ValueError("deadline overflow")
        pending.append(request)
        used += request["tokens"]
        if len(pending) == max_items or used == max_tokens or max_wait_ms == 0:
            flush(arrival)
    if pending:
        flush(deadline)
    waits = [wait for batch in batches for wait in batch["wait_ms"].values()]
    return {"batches": batches, "mean_wait_ms": sum(waits) / len(waits) if waits else 0,
            "max_observed_wait_ms": max(waits, default=0)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    args = parser.parse_args()
    try:
        input_path = Path(args.input)
        if not input_path.is_absolute():
            input_path = Path(__file__).resolve().parent / input_path
        with input_path.open(encoding="utf-8") as handle:
            data = json.load(handle)
        print(json.dumps(schedule(data["requests"], data["max_tokens"], data["max_items"], data["max_wait_ms"]),
                         indent=2, allow_nan=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError) as error:
        print(f"Invalid schedule: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
