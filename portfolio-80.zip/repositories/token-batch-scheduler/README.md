# Token batch scheduler

Simulate FIFO microbatches for token-counted inference requests. This is an admission/scheduling exercise; it does not run an inference engine.

~~~sh
python3 main.py --input example.json
python3 -m unittest -v
~~~

Requests are stably sorted by arrival time. A batch dispatches when its item/token cap is reached, when the next arrived request cannot fit, or when its oldest request reaches the maximum wait. A request arriving exactly at the deadline can join that batch. Oversized individual requests are rejected. The final partial batch waits for its deadline, modeling a running service without an end-of-stream signal.

The report exposes per-request wait time and batch composition. It assumes dispatch is instantaneous and unconstrained; GPU execution duration, padding, decoding length, concurrency, and head-of-line work already executing are not modeled.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
