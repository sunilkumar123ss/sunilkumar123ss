import unittest
from main import schedule


def item(name, arrival, tokens):
    return {"id": name, "arrival_ms": arrival, "tokens": tokens}


class SchedulerTests(unittest.TestCase):
    def test_capacity_and_fifo(self):
        result = schedule([item("a", 0, 6), item("b", 2, 5), item("c", 3, 5)], 10, 5, 10)
        self.assertEqual(result["batches"][0]["request_ids"], ["a"])
        self.assertEqual(result["batches"][0]["dispatch_ms"], 2)
        self.assertEqual(result["batches"][1]["request_ids"], ["b", "c"])
        self.assertEqual(result["batches"][1]["dispatch_ms"], 3)

    def test_deadline_and_equal_arrival_boundary(self):
        result = schedule([item("a", 0, 1), item("b", 5, 1), item("c", 20, 1)], 10, 10, 5)
        self.assertEqual(result["batches"][0]["request_ids"], ["a", "b"])
        self.assertEqual(result["batches"][0]["dispatch_ms"], 5)
        self.assertEqual(result["max_observed_wait_ms"], 5)

    def test_zero_wait_and_empty(self):
        self.assertEqual(len(schedule([item("a", 0, 1), item("b", 0, 1)], 10, 10, 0)["batches"]), 2)
        self.assertEqual(schedule([], 10, 10, 5)["mean_wait_ms"], 0)

    def test_invalid_oversized_and_duplicate(self):
        with self.assertRaises(ValueError):
            schedule([item("a", 0, 11)], 10, 10, 5)
        with self.assertRaises(ValueError):
            schedule([item("a", 0, 1), item("a", 1, 1)], 10, 10, 5)


if __name__ == "__main__":
    unittest.main()
