"""Bounded read-only queries for a small trusted SQLite database."""
import argparse
import json
from pathlib import Path
import sqlite3
import tempfile

SAFE_FUNCTIONS = {"abs", "avg", "coalesce", "count", "length", "lower", "max", "min", "round", "sum", "upper", "like", "substr"}


def execute_readonly(database, query, parameters=(), limit=20, step_budget=10000, tables=("documents",)):
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
        raise ValueError("limit must be an integer from 1 to 1000")
    if isinstance(step_budget, bool) or not isinstance(step_budget, int) or step_budget < 100:
        raise ValueError("step_budget must be an integer of at least 100")
    if not isinstance(query, str) or not query.strip() or len(query) > 10000:
        raise ValueError("query must contain 1..10000 characters")
    if not isinstance(tables, (tuple, list, set, frozenset)) or any(not isinstance(name, str) or not name for name in tables):
        raise ValueError("tables must be a collection of nonempty table names")
    allowed_tables = set(tables)
    uri = Path(database).resolve().as_uri() + "?mode=ro"
    try:
        connection = sqlite3.connect(uri, uri=True, timeout=0.25)
    except sqlite3.Error as exc:
        raise ValueError(f"cannot open read-only database: {exc}") from exc
    try:
        connection.execute("PRAGMA query_only=ON")
        def authorize(action, arg1, arg2, database_name, trigger):
            if action == sqlite3.SQLITE_SELECT or action == sqlite3.SQLITE_RECURSIVE:
                return sqlite3.SQLITE_OK
            if action == sqlite3.SQLITE_READ:
                return sqlite3.SQLITE_OK if arg1 in allowed_tables and database_name == "main" else sqlite3.SQLITE_DENY
            if action == sqlite3.SQLITE_FUNCTION:
                return sqlite3.SQLITE_OK if (arg2 or "").casefold() in SAFE_FUNCTIONS else sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_DENY
        connection.set_authorizer(authorize)
        spent = 0
        def progress():
            nonlocal spent
            spent += 100
            return int(spent >= step_budget)
        connection.set_progress_handler(progress, 100)
        cursor = connection.execute(query, parameters)
        rows = cursor.fetchmany(limit + 1)
        return {"columns": [column[0] for column in cursor.description or []],
                "rows": rows[:limit], "truncated": len(rows) > limit}
    except (sqlite3.Error, sqlite3.Warning) as exc:
        raise ValueError(f"query rejected or budget exceeded: {exc}") from exc
    finally:
        connection.close()


def create_demo_database(path):
    with sqlite3.connect(path) as connection:
        connection.executescript(Path(__file__).with_name("fixture.sql").read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", type=Path)
    parser.add_argument("--query", default="SELECT id, title FROM documents ORDER BY id")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--step-budget", type=int, default=10000)
    args = parser.parse_args()
    try:
        if args.database:
            result = execute_readonly(args.database, args.query, limit=args.limit, step_budget=args.step_budget)
        else:
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / "demo.sqlite"
                create_demo_database(path)
                result = execute_readonly(path, args.query, limit=args.limit, step_budget=args.step_budget)
    except (ValueError, OSError, sqlite3.Error) as exc:
        parser.error(str(exc))
    print(json.dumps(result, indent=2))

if __name__ == "__main__": main()
