CREATE TABLE documents(id INTEGER PRIMARY KEY, title TEXT, category TEXT);
INSERT INTO documents VALUES(1,'Voice latency guide','voice'),(2,'Retrieval evaluation','rag'),(3,'Agent audit trail','agents');
CREATE TABLE private_notes(note TEXT);
INSERT INTO private_notes VALUES('synthetic private value');
