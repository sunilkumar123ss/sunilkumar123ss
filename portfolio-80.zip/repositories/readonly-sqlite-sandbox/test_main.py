from pathlib import Path
import sqlite3
import tempfile
import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
create_demo_database = _main.create_demo_database
execute_readonly = _main.execute_readonly

class SQLTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "demo.db"
        create_demo_database(self.path)
    def test_parameterized_select_and_limit(self):
        result = execute_readonly(self.path, "SELECT title FROM documents WHERE category = ?", ("voice",))
        self.assertEqual(result["rows"], [("Voice latency guide",)])
        self.assertTrue(execute_readonly(self.path, "SELECT * FROM documents", limit=1)["truncated"])
    def test_writes_hidden_tables_and_multistatements_rejected(self):
        for query in ["DELETE FROM documents", "SELECT * FROM private_notes", "PRAGMA table_info(documents)",
                      "SELECT 1; SELECT 2", "SELECT load_extension('anything')", "ATTACH DATABASE ':memory:' AS x"]:
            with self.subTest(query=query), self.assertRaises(ValueError):
                execute_readonly(self.path, query)
        with sqlite3.connect(self.path) as connection:
            self.assertEqual(connection.execute("SELECT count(*) FROM documents").fetchone()[0], 3)
    def test_vm_budget_interrupts_recursive_query(self):
        query = "WITH RECURSIVE seq(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM seq) SELECT sum(x) FROM seq"
        with self.assertRaisesRegex(ValueError, "interrupted"):
            execute_readonly(self.path, query, step_budget=1000)
    def test_view_cannot_expose_disallowed_table(self):
        with sqlite3.connect(self.path) as connection:
            connection.execute("CREATE VIEW exposed AS SELECT * FROM private_notes")
        with self.assertRaises(ValueError):
            execute_readonly(self.path, "SELECT * FROM exposed", tables=("exposed",))
    def test_readonly_connection_remains_safe_when_table_allowlist_expands(self):
        with self.assertRaises(ValueError):
            execute_readonly(self.path, "UPDATE documents SET title = 'changed'", tables=("documents", "private_notes"))
    def test_missing_file_is_not_created(self):
        missing = self.path.with_name("missing.db")
        with self.assertRaisesRegex(ValueError, "cannot open read-only"):
            execute_readonly(missing, "SELECT 1")
        self.assertFalse(missing.exists())
    def test_input_bounds(self):
        with self.assertRaises(ValueError): execute_readonly(self.path, "SELECT 1", limit=0)
        with self.assertRaises(ValueError): execute_readonly(self.path, "SELECT 1", tables="documents")

if __name__ == "__main__": unittest.main()
