# Read-only SQLite query sandbox

Runnable educational demo/starter with synthetic examples.

Executes SQL against a read-only SQLite connection with a table allowlist, SQL authorizer, function allowlist, VM-step budget, row cap, and multi-statement rejection. The default creates an isolated temporary database from the trusted synthetic fixture. Use `--database /path/to/file.db --query "SELECT ..."` for a local database. The table allowlist is `documents`; reads of other tables, writes, PRAGMAs, attachments and extension loading are denied. This is a defense-in-depth demo, not a process/container isolation boundary for hostile SQLite database files.

## Run

Python 3.10+; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

No network requests, credentials, or paid services are used. Any model/provider integration would be a separate adapter. Read `main.py` for the public functions and `test_main.py` for success/failure invariants. Fixture content is synthetic.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
