"""Deterministic evidence packing under a transparent heuristic unit budget."""
import argparse
import json
import math
from pathlib import Path
import re


def units(text):
    return len(re.findall(r"\w+|[^\w\s]",text,flags=re.UNICODE))


def render(item):
    return f"[{item['id']}]\n{item['text']}\n"


def pack(items,budget=75,reserved=10):
    if any(isinstance(x,bool) or not isinstance(x,int) or x < 0 for x in (budget,reserved)) or reserved > budget:
        raise ValueError("budget and reserved must be nonnegative integers; reserved <= budget")
    if not isinstance(items,list):raise ValueError("items must be a list")
    seen=set();normalized=[]
    for item in items:
        if not isinstance(item,dict) or not isinstance(item.get("id"),str) or not item["id"] or item["id"] in seen or not isinstance(item.get("text"),str):
            raise ValueError("items need unique IDs and text")
        priority=item.get("priority",0);required=item.get("required",False)
        if isinstance(priority,bool) or not isinstance(priority,(int,float)) or not math.isfinite(priority) or not isinstance(required,bool):
            raise ValueError("priority must be finite; required must be boolean")
        seen.add(item["id"])
        normalized.append({**item,"priority":priority,"required":required,"cost":units(render(item))})
    selected=[item for item in normalized if item["required"]]
    used=reserved+sum(item["cost"] for item in selected)
    if used > budget:raise ValueError("required evidence exceeds the budget")
    optional=sorted((item for item in normalized if not item["required"]),key=lambda item:(-item["priority"],item["id"]))
    for item in optional:
        if used+item["cost"] <= budget:
            selected.append(item);used+=item["cost"]
    selected_ids={item["id"] for item in selected}
    return {"context":"".join(render(item) for item in selected),"selected_ids":[item["id"] for item in selected],
            "excluded_ids":[item["id"] for item in normalized if item["id"] not in selected_ids],
            "used_units":used,"reserved_units":reserved,"budget_units":budget,"estimator":"word/punctuation units, not model tokens"}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--items",type=Path,default=Path(__file__).with_name("items.json"))
    parser.add_argument("--budget",type=int,default=55)
    parser.add_argument("--reserved",type=int,default=10)
    args=parser.parse_args()
    try:result=pack(json.loads(args.items.read_text()),args.budget,args.reserved)
    except (ValueError,OSError,TypeError) as exc:parser.error(str(exc))
    print(json.dumps(result,indent=2))

if __name__ == "__main__":main()
