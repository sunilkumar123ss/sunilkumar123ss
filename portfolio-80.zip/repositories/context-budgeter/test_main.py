import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
pack = _main.pack
units = _main.units

class BudgetTests(unittest.TestCase):
    def test_budget_and_required_preserved(self):
        items=[{"id":"a","text":"required text","required":True},{"id":"b","text":"optional text","priority":5}]
        result=pack(items,budget=8,reserved=1)
        self.assertIn("a",result["selected_ids"])
        self.assertLessEqual(result["used_units"],8)
        self.assertEqual(result["used_units"],units(result["context"])+1)
    def test_required_overflow_is_explicit(self):
        with self.assertRaises(ValueError):pack([{"id":"a","text":"too many words","required":True}],budget=1,reserved=0)
    def test_priority_and_tie_deterministic(self):
        items=[{"id":"b","text":"x","priority":1},{"id":"a","text":"y","priority":1}]
        self.assertEqual(pack(items,4,0)["selected_ids"],["a"])
    def test_duplicate_id_and_invalid_budget(self):
        with self.assertRaises(ValueError):pack([{"id":"x","text":"x"},{"id":"x","text":"y"}])
        with self.assertRaises(ValueError):pack([],budget=1,reserved=2)

if __name__ == "__main__":unittest.main()
