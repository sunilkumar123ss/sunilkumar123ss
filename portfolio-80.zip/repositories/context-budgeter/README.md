# Priority-aware context budgeter

Runnable educational demo/starter with synthetic examples.

Packs required and optional evidence into a bounded context using a documented word/punctuation-unit estimator. Required evidence either fits completely or causes a clear error; optional evidence is selected by priority with deterministic ties. The estimator is not any provider’s tokenizer, so the budget is not a guarantee of a model context limit. A provider adapter must replace `units` with that model’s actual tokenizer.

## Run

Python 3.10+; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

No network requests, credentials, or paid services are used. Any model/provider integration would be a separate adapter. Read `main.py` for the public functions and `test_main.py` for success/failure invariants. Fixture content is synthetic.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
