import io
import struct
import unittest
import wave
try:
    from .main import encode_wav, segment_wav
except ImportError:
    from main import encode_wav, segment_wav

class WavTests(unittest.TestCase):

    def test_lossless_nonoverlap(self):
        raw = struct.pack('<10h', *range(10))
        result = segment_wav(encode_wav(raw, 1000), 4)
        chunks = result['segments']
        self.assertEqual([(x['start_frame'], x['end_frame']) for x in chunks], [(0, 4), (4, 8), (8, 10)])
        rebuilt = b''
        for x in chunks:
            with wave.open(io.BytesIO(x['wav']), 'rb') as w:
                rebuilt += w.readframes(w.getnframes())
        self.assertEqual(rebuilt, raw)

    def test_stereo_overlap_preserves_frames(self):
        result = segment_wav(encode_wav(struct.pack('<20h', *range(20)), 1000, 2), 6, 2)
        self.assertEqual([(x['start_frame'], x['end_frame']) for x in result['segments']], [(0, 6), (4, 10)])
        self.assertEqual(result['channels'], 2)

    def test_empty(self):
        self.assertEqual(segment_wav(encode_wav(b''))['segments'], [])

    def test_invalid(self):
        for (duration, overlap) in [(0, 0), (10, 10), (10, -1), (float('nan'), 0), (1e+308, 0)]:
            with self.assertRaises(ValueError):
                segment_wav(encode_wav(b''), duration, overlap)
        with self.assertRaises(ValueError):
            segment_wav(b'broken')

    def test_truncated(self):
        with self.assertRaises(ValueError):
            segment_wav(encode_wav(struct.pack('<10h', *range(10)))[:-4])
if __name__ == '__main__':
    unittest.main()
