"""Segment PCM WAV containers without pretending to recognize speech."""
import argparse
import io
import json
import math
from pathlib import Path
import struct
import wave

def encode_wav(frames, rate=8000, channels=1):
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as w:
        w.setnchannels(channels)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(frames)
    return stream.getvalue()

def segment_wav(data, duration_ms=300, overlap_ms=0):
    for (name, value) in (('duration_ms', duration_ms), ('overlap_ms', overlap_ms)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or (not math.isfinite(value)):
            raise ValueError(name + ' must be finite')
    if duration_ms <= 0 or duration_ms > 86400000 or overlap_ms < 0 or (overlap_ms >= duration_ms):
        raise ValueError('Require 0 <= overlap < duration <= 86400000 ms')
    if not isinstance(data, bytes):
        raise ValueError('WAV input must be bytes')
    try:
        with wave.open(io.BytesIO(data), 'rb') as w:
            (channels, width, rate, count) = (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes())
            if width != 2 or channels not in (1, 2) or w.getcomptype() != 'NONE':
                raise ValueError('Only uncompressed 16-bit mono/stereo PCM is supported')
            frames = w.readframes(count)
    except (wave.Error, EOFError) as exc:
        raise ValueError('Invalid WAV container') from exc
    stride = channels * width
    if len(frames) != count * stride:
        raise ValueError('Truncated WAV frame data')
    length = int(rate * duration_ms / 1000)
    overlap = int(rate * overlap_ms / 1000)
    if length < 1 or length <= overlap:
        raise ValueError('Duration/overlap must resolve to a positive frame step')
    result = []
    start = 0
    while start < count:
        end = min(start + length, count)
        result.append({'start_frame': start, 'end_frame': end, 'wav': encode_wav(frames[start * stride:end * stride], rate, channels)})
        if end == count:
            break
        start += length - overlap
    return {'sample_rate': rate, 'channels': channels, 'input_frames': count, 'segments': result}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='16-bit PCM WAV; omitted uses a synthetic tone')
    parser.add_argument('--duration-ms', type=float, default=300)
    parser.add_argument('--overlap-ms', type=float, default=50)
    parser.add_argument('--output-dir', type=Path, help='Optional destination for chunk WAVs')
    args = parser.parse_args()
    try:
        data = args.input.read_bytes() if args.input else encode_wav(b''.join((struct.pack('<h', int(8000 * math.sin(2 * math.pi * 220 * i / 8000))) for i in range(8000))))
        result = segment_wav(data, args.duration_ms, args.overlap_ms)
        if args.output_dir:
            args.output_dir.mkdir(parents=True, exist_ok=True)
            destinations = [args.output_dir / ('segment_%03d.wav' % index) for index in range(len(result['segments']))]
            if any((path.exists() for path in destinations)):
                raise ValueError('Refusing to overwrite an existing segment WAV')
        for (index, item) in enumerate(result['segments']):
            blob = item.pop('wav')
            item['wav_bytes'] = len(blob)
            if args.output_dir:
                path = args.output_dir / ('segment_%03d.wav' % index)
                with path.open('xb') as handle:
                    handle.write(blob)
                item['file'] = str(path)
        result['source'] = 'input PCM WAV' if args.input else 'synthetic 220 Hz tone; not speech inference'
        print(json.dumps(result, indent=2))
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
