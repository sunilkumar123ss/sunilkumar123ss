# PCM WAV Segmenter

**Demo/starter · Python standard library only.**

Split a real PCM WAV container into independently playable chunks while preserving frame boundaries, sample rate and channel layout.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/tone.wav --duration-ms 40 --overlap-ms 10
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input is an uncompressed 16-bit mono or stereo WAV file. Durations are milliseconds. Output reports each chunk’s start and end frame and byte length. Add `--output-dir output` to write the chunk WAVs; without that option, the CLI only prints metadata. The final chunk can be shorter, and no padding is added. Existing segment files are never silently overwritten.

## Limits and optional provider boundary

This is fixed-window segmentation, not speech-aware segmentation. Other bit depths and codecs are rejected. Input is loaded in memory; chunk duration is limited to one day. `fixtures/tone.wav` is a mathematically generated 220 Hz tone, not recorded speech.

An optional ASR adapter could consume the returned WAV bytes and offsets. No provider, model or inference runs here.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
