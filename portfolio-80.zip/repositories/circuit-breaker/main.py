"""A synchronous circuit breaker with consecutive failures and a recovery probe."""
import argparse
import json
import math


class CircuitOpenError(RuntimeError):
    pass


class CircuitBreaker:
    def __init__(self, failure_threshold=3, recovery_seconds=10):
        if type(failure_threshold) is not int or failure_threshold <= 0:
            raise ValueError("failure_threshold must be a positive integer")
        if isinstance(recovery_seconds, bool) or not isinstance(recovery_seconds, (int, float)):
            raise ValueError("recovery_seconds must be positive and finite")
        if not math.isfinite(recovery_seconds) or recovery_seconds <= 0:
            raise ValueError("recovery_seconds must be positive and finite")
        self.failure_threshold = failure_threshold
        self.recovery_seconds = recovery_seconds
        self.state = "closed"
        self.failures = 0
        self._opened_at = None
        self._last_now = None
        self._running = False

    def call(self, operation, now):
        if isinstance(now, bool) or not isinstance(now, (int, float)) or not math.isfinite(now):
            raise ValueError("now must be finite")
        if self._last_now is not None and now < self._last_now:
            raise ValueError("clock must not move backwards")
        self._last_now = now
        if self._running:
            raise CircuitOpenError("another operation is already running")
        if self.state == "open":
            if now - self._opened_at < self.recovery_seconds:
                raise CircuitOpenError("recovery timeout has not elapsed")
            self.state = "half-open"
        self._running = True
        try:
            result = operation()
        except Exception:
            self.failures += 1
            if self.state == "half-open" or self.failures >= self.failure_threshold:
                self.state = "open"
                self._opened_at = now
            raise
        else:
            self.state = "closed"
            self.failures = 0
            self._opened_at = None
            return result
        finally:
            self._running = False


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    breaker = CircuitBreaker(failure_threshold=2, recovery_seconds=5)
    events = []
    for timestamp, should_fail in ((0, True), (1, True), (2, False), (6, False), (7, False)):
        def operation():
            if should_fail:
                raise OSError("synthetic dependency unavailable")
            return "synthetic response"
        try:
            outcome = breaker.call(operation, timestamp)
        except (OSError, CircuitOpenError) as exc:
            outcome = type(exc).__name__
        events.append({"at": timestamp, "outcome": outcome, "state": breaker.state})
    print(json.dumps(events, indent=2))


if __name__ == "__main__":
    main()
