import unittest
from main import CircuitBreaker, CircuitOpenError


def fail():
    raise OSError("synthetic failure")


class CircuitBreakerTests(unittest.TestCase):
    def test_opens_at_threshold(self):
        breaker = CircuitBreaker(2, 5)
        with self.assertRaises(OSError): breaker.call(fail, 0)
        self.assertEqual(breaker.state, "closed")
        with self.assertRaises(OSError): breaker.call(fail, 1)
        self.assertEqual(breaker.state, "open")

    def test_open_short_circuits_callback(self):
        breaker = CircuitBreaker(1, 5)
        with self.assertRaises(OSError): breaker.call(fail, 0)
        calls = []
        with self.assertRaises(CircuitOpenError): breaker.call(lambda: calls.append(1), 4)
        self.assertEqual(calls, [])

    def test_success_resets_consecutive_failures(self):
        breaker = CircuitBreaker(2, 5)
        with self.assertRaises(OSError): breaker.call(fail, 0)
        self.assertEqual(breaker.call(lambda: 42, 1), 42)
        with self.assertRaises(OSError): breaker.call(fail, 2)
        self.assertEqual(breaker.state, "closed")
        self.assertEqual(breaker.failures, 1)

    def test_probe_at_exact_timeout_closes(self):
        breaker = CircuitBreaker(1, 5)
        with self.assertRaises(OSError): breaker.call(fail, 0)
        states = []
        breaker.call(lambda: states.append(breaker.state), 5)
        self.assertEqual(states, ["half-open"])
        self.assertEqual(breaker.state, "closed")

    def test_failed_probe_restarts_timeout(self):
        breaker = CircuitBreaker(1, 5)
        with self.assertRaises(OSError): breaker.call(fail, 0)
        with self.assertRaises(OSError): breaker.call(fail, 5)
        with self.assertRaises(CircuitOpenError): breaker.call(lambda: 1, 9)
        self.assertEqual(breaker.call(lambda: 1, 10), 1)

    def test_reentrant_operation_is_rejected(self):
        breaker = CircuitBreaker(2, 5)
        with self.assertRaises(CircuitOpenError):
            breaker.call(lambda: breaker.call(lambda: None, 0), 0)
        self.assertEqual(breaker.call(lambda: "ok", 1), "ok")

    def test_validation_and_backwards_clock(self):
        with self.assertRaises(ValueError): CircuitBreaker(0, 1)
        with self.assertRaises(ValueError): CircuitBreaker(1, float('nan'))
        breaker = CircuitBreaker()
        breaker.call(lambda: None, 3)
        with self.assertRaises(ValueError): breaker.call(lambda: None, 2)


if __name__ == '__main__':
    unittest.main()
