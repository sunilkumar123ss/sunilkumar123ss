# Circuit Breaker

Explore failure thresholds, short-circuiting, and recovery probes.

All bundled examples use synthetic data.

## Run

Requires Python 3.9 or later; no third-party packages or network access are needed.

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

Run these commands from this repository's directory. The demo can also be launched from any directory by passing the absolute path to `main.py`.

## How it works

Closed state executes the callback and counts consecutive ordinary exceptions. Success resets the counter. Reaching the threshold opens the circuit, and calls before the recovery timeout fail without executing their callbacks. At the timeout boundary, one synchronous probe runs in half-open state. A successful probe closes the circuit; a failed probe opens it for another timeout.

The supplied timestamp records call admission, including the opening instant. State transitions use O(1) bookkeeping.

## Reuse

```python
from main import CircuitBreaker, CircuitOpenError

breaker = CircuitBreaker(failure_threshold=2, recovery_seconds=5)
response = breaker.call(lambda: {"synthetic": "ok"}, now=0)
assert response["synthetic"] == "ok"
```

## Demo behavior

The demo injects two synthetic `OSError` failures, observes a blocked request, and then performs a successful recovery probe. It makes no network calls.

## Boundaries

The class is synchronous and not thread-safe. It rejects reentrant operations; it is not an asynchronous bulkhead. It counts every `Exception` raised by the callback, so an integration should distinguish dependency failures from application errors. There are no timeouts, retry loops, rolling failure ratios, or background probes. `BaseException` subclasses such as keyboard interruption are not counted as dependency failures.

## Verification

`test_main.py` exercises boundary conditions, invalid inputs, and meaningful behavior specific to this implementation. The default demo is deterministic and completes without external services. See the collection's verification report for the recorded run; run the commands above to verify this repository independently.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
