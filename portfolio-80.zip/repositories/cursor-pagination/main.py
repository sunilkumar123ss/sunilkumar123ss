"""Keyset pagination over a stable (created_at, record_id) order."""
import argparse
import base64
import binascii
from dataclasses import asdict, dataclass
import json
import re


@dataclass(frozen=True)
class Record:
    created_at: int
    record_id: str
    title: str

    @property
    def key(self):
        return self.created_at, self.record_id


@dataclass(frozen=True)
class Page:
    items: tuple
    next_cursor: object


def encode_cursor(key):
    raw = json.dumps({"v": 1, "after": list(key)}, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def decode_cursor(cursor):
    if not isinstance(cursor, str) or len(cursor) > 4096 or not re.fullmatch(r"[A-Za-z0-9_-]+", cursor):
        raise ValueError("invalid cursor encoding")
    try:
        raw = base64.b64decode(cursor + "=" * (-len(cursor) % 4), altchars=b"-_", validate=True)
        data = json.loads(raw.decode("utf-8"))
    except (binascii.Error, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid cursor encoding") from exc
    if not isinstance(data, dict) or set(data) != {"v", "after"} or type(data["v"]) is not int or data["v"] != 1:
        raise ValueError("unsupported cursor format")
    after = data["after"]
    if (not isinstance(after, list) or len(after) != 2 or type(after[0]) is not int
            or after[0] < 0 or not isinstance(after[1], str) or not after[1]):
        raise ValueError("invalid cursor key")
    return tuple(after)


def paginate(records, limit=20, cursor=None):
    if type(limit) is not int or not 1 <= limit <= 100:
        raise ValueError("limit must be an integer between 1 and 100")
    after = None if cursor is None else decode_cursor(cursor)
    records = list(records)
    for record in records:
        if (not isinstance(record, Record) or type(record.created_at) is not int
                or record.created_at < 0 or not isinstance(record.record_id, str) or not record.record_id):
            raise ValueError("records need nonnegative integer timestamps and nonempty string IDs")
    ordered = sorted(records, key=lambda record: record.key)
    if len({record.key for record in ordered}) != len(ordered):
        raise ValueError("ordering keys must be unique")
    remaining = [record for record in ordered if after is None or record.key > after]
    items = tuple(remaining[:limit])
    next_cursor = encode_cursor(items[-1].key) if len(remaining) > limit else None
    return Page(items, next_cursor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=2, help="synthetic page size, 1 to 100")
    args = parser.parse_args()
    records = [Record(100, "c", "Cache"), Record(100, "a", "API"),
               Record(101, "d", "Database"), Record(100, "b", "Batch")]
    try:
        pages = []
        cursor = None
        while True:
            page = paginate(records, args.limit, cursor)
            pages.append({"items": [asdict(item) for item in page.items], "next_cursor": page.next_cursor})
            if page.next_cursor is None:
                break
            cursor = page.next_cursor
    except ValueError as exc:
        parser.error(str(exc))
    print(json.dumps(pages, indent=2))


if __name__ == "__main__":
    main()
