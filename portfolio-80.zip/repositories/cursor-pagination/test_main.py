import base64
import json
import unittest
from main import Record, paginate, decode_cursor, encode_cursor


class CursorPaginationTests(unittest.TestCase):
    def setUp(self):
        self.records = [Record(1, "c", "C"), Record(1, "a", "A"), Record(1, "b", "B"), Record(2, "d", "D")]

    def test_tied_timestamps_have_stable_order(self):
        page = paginate(self.records, 2)
        self.assertEqual([r.record_id for r in page.items], ["a", "b"])
        second = paginate(self.records, 2, page.next_cursor)
        self.assertEqual([r.record_id for r in second.items], ["c", "d"])
        self.assertIsNone(second.next_cursor)

    def test_empty_and_exactly_full_terminal_pages(self):
        self.assertEqual(paginate([], 2).items, ())
        self.assertIsNone(paginate(self.records, 4).next_cursor)

    def test_deleted_anchor_still_advances(self):
        cursor = paginate(self.records, 2).next_cursor
        remaining = [r for r in self.records if r.record_id != "b"]
        self.assertEqual([r.record_id for r in paginate(remaining, 2, cursor).items], ["c", "d"])

    def test_insert_before_anchor_does_not_repeat(self):
        cursor = paginate(self.records, 2).next_cursor
        records = self.records + [Record(0, "new", "earlier")]
        self.assertEqual([r.record_id for r in paginate(records, 10, cursor).items], ["c", "d"])

    def test_invalid_cursor_and_version(self):
        invalid = ["", "not!base64", "a", base64.urlsafe_b64encode(b'{"v":2,"after":[1,"a"]}').decode().rstrip("=")]
        for cursor in invalid:
            with self.subTest(cursor=cursor), self.assertRaises(ValueError): decode_cursor(cursor)

    def test_cursor_round_trip_unicode_id(self):
        self.assertEqual(decode_cursor(encode_cursor((12, "demo-\u03bb"))), (12, "demo-\u03bb"))

    def test_duplicate_keys_and_invalid_limit(self):
        with self.assertRaises(ValueError): paginate([Record(1, "a", "x"), Record(1, "a", "y")])
        for limit in (0, 101, True):
            with self.subTest(limit=limit), self.assertRaises(ValueError): paginate(self.records, limit)

    def test_cursor_after_dataset(self):
        page = paginate(self.records, 2, encode_cursor((999, "z")))
        self.assertEqual(page.items, ())
        self.assertIsNone(page.next_cursor)


if __name__ == '__main__':
    unittest.main()
