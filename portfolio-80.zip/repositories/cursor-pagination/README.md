# Cursor Pagination

Page through records using a stable compound key and opaque cursors.

All bundled examples use synthetic data.

## Run

Requires Python 3.9 or later; no third-party packages or network access are needed.

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

Run these commands from this repository's directory. The demo can also be launched from any directory by passing the absolute path to `main.py`.

## How it works

Records are ordered by `(created_at, record_id)`, with the ID breaking timestamp ties. The next page selects keys strictly greater than the cursor anchor. A next cursor is returned only when more records exist. Versioned JSON cursor data is encoded as unpadded URL-safe Base64; malformed encodings, unsupported versions, and invalid key types are rejected.

The in-memory reference implementation sorts each call in O(n log n) time and uses O(n) memory. A database implementation would apply the same comparison to an appropriate compound index.

## Reuse

```python
from main import Record, paginate

records = [Record(10, "b", "Second"), Record(10, "a", "First"), Record(11, "c", "Third")]
first = paginate(records, limit=2)
assert [row.record_id for row in first.items] == ["a", "b"]
second = paginate(records, limit=2, cursor=first.next_cursor)
assert [row.record_id for row in second.items] == ["c"]
assert second.next_cursor is None
```

## Demo behavior

Run `python3 main.py --limit 1` to view four single-record pages. The default demo uses a page size of two and intentionally supplies unsorted synthetic records.

## Boundaries

Base64 is an encoding, not authentication: a client can construct a different anchor. Cursors are not bound to filters, users, or a dataset snapshot. New records before the current anchor will not appear during that traversal, and updates to ordering keys can affect traversal. Ordering keys must be unique and immutable for predictable results. Only nonnegative integer timestamps and nonempty string IDs are supported.

## Verification

`test_main.py` exercises boundary conditions, invalid inputs, and meaningful behavior specific to this implementation. The default demo is deterministic and completes without external services. See the collection's verification report for the recorded run; run the commands above to verify this repository independently.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
