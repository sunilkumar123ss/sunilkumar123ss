import unittest
try:
    from .main import route
except ImportError:
    from main import route

class RouteTests(unittest.TestCase):

    def test_command(self):
        self.assertEqual(route('Please SWITCH ON the light!')['intent'], 'lights_on')
        self.assertEqual(route('what is the weather?')['intent'], 'weather')

    def test_ambiguous(self):
        self.assertEqual(route('turn on the light and turn off the light')['reason'], 'multiple_intents')

    def test_low_confidence_and_negation(self):
        self.assertEqual(route('turn on light', 0.2)['reason'], 'low_supplied_asr_confidence')
        self.assertEqual(route('do not turn on light')['reason'], 'negated_command')

    def test_curly_apostrophe_negation(self):
        self.assertEqual(route('don’t turn on the light')['reason'], 'negated_command')

    def test_unknown_and_cancel(self):
        self.assertEqual(route('send a payment')['reason'], 'unknown_command')
        self.assertEqual(route('never mind')['intent'], 'cancel')
        self.assertEqual(route('')['reason'], 'empty_transcript')

    def test_invalid(self):
        for confidence in [True, -0.1, 1.1, float('nan')]:
            with self.assertRaises(ValueError):
                route('weather', confidence)
        with self.assertRaises(ValueError):
            route(None)
if __name__ == '__main__':
    unittest.main()
