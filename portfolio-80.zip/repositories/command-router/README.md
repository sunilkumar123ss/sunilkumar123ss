# Transcript Command Router

**Demo/starter · Python standard library only.**

Route a small explicit command grammar while refusing ambiguity, negation and low supplied confidence.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input JSON contains `text` and optional `asr_confidence`, or use `--text`. Known intents are lights_on, lights_off, weather and cancel. The result is `route_only` or `clarify` with a reason. Multiple intents never execute an action. Confidence is supplied metadata, not estimated by this code.

## Limits and optional provider boundary

This is not ASR, a semantic LLM, a general intent classifier or a calibrated confidence model. Paraphrases can be missed and context can be ambiguous. Treat the output as a proposal subject to application policy. No device or external action occurs.

An optional ASR adapter could supply transcript text. The bundled transcript is invented and does not imply audio inference.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
