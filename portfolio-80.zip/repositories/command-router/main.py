"""Route provided command transcripts with explicit ambiguity and confidence gates."""
import argparse
import json
import math
import re
from pathlib import Path
RULES = {'lights_on': ['\\b(?:turn|switch) on (?:the )?lights?\\b'], 'lights_off': ['\\b(?:turn|switch) off (?:the )?lights?\\b'], 'weather': ['\\bweather\\b', '\\btemperature outside\\b'], 'cancel': ['^(?:cancel|stop|never mind|nevermind)$']}

def route(text, asr_confidence=1.0, minimum_confidence=0.7):
    if not isinstance(text, str) or len(text) > 2000:
        raise ValueError('Transcript must be a string of at most2000characters')
    for value in (asr_confidence, minimum_confidence):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or (not math.isfinite(value)) or (not 0 <= value <= 1):
            raise ValueError('Confidence must be finite in [0,1]')
    normalized = ' '.join(re.sub("[^\\w\\s']", ' ', text.casefold().replace('’', "'")).split())
    if not normalized:
        return {'action': 'clarify', 'reason': 'empty_transcript', 'intent': None}
    if asr_confidence < minimum_confidence:
        return {'action': 'clarify', 'reason': 'low_supplied_asr_confidence', 'intent': None}
    if re.search("\\b(?:don't|do not|never|not|no)\\b", normalized) and normalized != 'never mind':
        return {'action': 'clarify', 'reason': 'negated_command', 'intent': None}
    matches = sorted((name for (name, patterns) in RULES.items() if any((re.search(pattern, normalized) for pattern in patterns))))
    if not matches:
        return {'action': 'clarify', 'reason': 'unknown_command', 'intent': None}
    if len(matches) > 1:
        return {'action': 'clarify', 'reason': 'multiple_intents', 'intent': None, 'candidates': matches}
    return {'action': 'route_only', 'intent': matches[0], 'normalized_transcript': normalized, 'note': 'No device or external action executed'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON {text:str, asr_confidence:0..1}')
    parser.add_argument('--text', help='Use a transcript directly, not an audio recording')
    args = parser.parse_args()
    if args.input and args.text is not None:
        parser.error('Use either--input or--text')
    try:
        p = json.loads(args.input.read_text()) if args.input else {'text': args.text if args.text is not None else 'Please turn on the light', 'asr_confidence': 0.95}
        if not isinstance(p, dict):
            raise ValueError('Input must be an object')
        print(json.dumps({'boundary': 'Rule-based transcript routing, not speech inference or an LLM', **route(p['text'], p.get('asr_confidence', 1.0))}, indent=2))
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
