"""An LRU cache with independent per-entry expiration and an injected clock."""
import argparse
from collections import OrderedDict
import json
import math


def positive_finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(name + " must be positive and finite")
    return float(value)


class TTLLRUCache:
    def __init__(self, maxsize, ttl_seconds):
        if type(maxsize) is not int or maxsize <= 0:
            raise ValueError("maxsize must be a positive integer")
        self.maxsize = maxsize
        self.ttl_seconds = positive_finite(ttl_seconds, "ttl_seconds")
        self._items = OrderedDict()
        self._last_now = None

    def _expire(self, now):
        if isinstance(now, bool) or not isinstance(now, (int, float)) or not math.isfinite(now):
            raise ValueError("now must be finite")
        if self._last_now is not None and now < self._last_now:
            raise ValueError("clock must not move backwards")
        self._last_now = now
        expired = [key for key, (_, expires_at) in self._items.items() if now >= expires_at]
        for key in expired:
            del self._items[key]

    def put(self, key, value, now, ttl_seconds=None):
        hash(key)
        ttl = self.ttl_seconds if ttl_seconds is None else positive_finite(ttl_seconds, "ttl_seconds")
        self._expire(now)
        self._items[key] = (value, now + ttl)
        self._items.move_to_end(key)
        while len(self._items) > self.maxsize:
            self._items.popitem(last=False)

    def get(self, key, now):
        hash(key)
        self._expire(now)
        value, _ = self._items[key]
        self._items.move_to_end(key)
        return value

    def keys(self, now):
        self._expire(now)
        return tuple(self._items)


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    cache = TTLLRUCache(maxsize=2, ttl_seconds=10)
    cache.put("a", "synthetic A", 0)
    cache.put("b", "synthetic B", 1)
    cache.get("a", 2)
    cache.put("c", "synthetic C", 3, ttl_seconds=2)
    after_eviction = cache.keys(3)
    after_expiry = cache.keys(5)
    print(json.dumps({"after_lru_eviction": after_eviction, "after_ttl_expiry": after_expiry,
                      "remaining_value": cache.get("a", 5)}, indent=2))


if __name__ == "__main__":
    main()
