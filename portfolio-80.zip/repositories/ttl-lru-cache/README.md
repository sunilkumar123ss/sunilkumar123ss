# TTL LRU Cache

Combine recency-based eviction with per-entry time limits.

All bundled examples use synthetic data.

## Run

Requires Python 3.9 or later; no third-party packages or network access are needed.

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

Run these commands from this repository's directory. The demo can also be launched from any directory by passing the absolute path to `main.py`.

## How it works

An `OrderedDict` keeps the least recently used key first. Reading a live entry promotes its recency without extending its expiry. Inserting or replacing a value sets a new TTL and promotes the key. Expired entries are removed before capacity eviction, so an expired recent item cannot displace a live older one.

Each operation scans current entries for expiration, making it O(n) in cache size. Lookup and recency changes are O(1) after that sweep. Memory is O(maxsize).

## Reuse

```python
from main import TTLLRUCache

cache = TTLLRUCache(maxsize=2, ttl_seconds=10)
cache.put("a", 1, now=0)
cache.put("b", 2, now=0, ttl_seconds=1)
cache.put("c", 3, now=2)
assert cache.keys(now=2) == ("a", "c")
assert cache.get("a", now=2) == 1
```

## Demo behavior

The demo makes one entry recent, triggers an LRU eviction, and then removes a different entry at its exact TTL boundary.

## Boundaries

The cache is not thread-safe and does not persist. Keys must be hashable. Values are stored by reference, so mutating a cached list or dictionary also changes the cached object. Expiration is lazy and happens only on a method call. Caller-provided times must be finite and nondecreasing; a live integration should use a monotonic clock.

## Verification

`test_main.py` exercises boundary conditions, invalid inputs, and meaningful behavior specific to this implementation. The default demo is deterministic and completes without external services. See the collection's verification report for the recorded run; run the commands above to verify this repository independently.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
