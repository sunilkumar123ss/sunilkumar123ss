import unittest
from main import TTLLRUCache


class CacheTests(unittest.TestCase):
    def test_get_promotes_recency(self):
        cache = TTLLRUCache(2, 10)
        cache.put("a", 1, 0)
        cache.put("b", 2, 0)
        cache.get("a", 1)
        cache.put("c", 3, 1)
        self.assertEqual(cache.keys(1), ("a", "c"))
        with self.assertRaises(KeyError): cache.get("b", 1)

    def test_exact_expiry_and_reads_do_not_extend_ttl(self):
        cache = TTLLRUCache(1, 5)
        cache.put("a", 1, 0)
        self.assertEqual(cache.get("a", 4), 1)
        with self.assertRaises(KeyError): cache.get("a", 5)

    def test_replacement_resets_ttl(self):
        cache = TTLLRUCache(1, 5)
        cache.put("a", 1, 0)
        cache.put("a", 2, 4)
        self.assertEqual(cache.get("a", 5), 2)
        with self.assertRaises(KeyError): cache.get("a", 9)

    def test_expired_newer_entry_removed_before_live_lru(self):
        cache = TTLLRUCache(2, 10)
        cache.put("a", 1, 0)
        cache.put("b", 2, 0, ttl_seconds=1)
        cache.put("c", 3, 2)
        self.assertEqual(cache.keys(2), ("a", "c"))

    def test_none_is_a_valid_value(self):
        cache = TTLLRUCache(1, 5)
        cache.put("none", None, 0)
        self.assertIsNone(cache.get("none", 0))

    def test_invalid_capacity_ttl_and_key(self):
        for maxsize, ttl in ((0, 1), (True, 1), (1, 0), (1, float('nan'))):
            with self.subTest(maxsize=maxsize, ttl=ttl), self.assertRaises(ValueError): TTLLRUCache(maxsize, ttl)
        with self.assertRaises(TypeError): TTLLRUCache(1, 5).put([], 1, 0)

    def test_backwards_clock_rejected(self):
        cache = TTLLRUCache(1, 5)
        cache.put("a", 1, 3)
        with self.assertRaises(ValueError): cache.get("a", 2)
        self.assertEqual(cache.get("a", 3), 1)


if __name__ == '__main__':
    unittest.main()
