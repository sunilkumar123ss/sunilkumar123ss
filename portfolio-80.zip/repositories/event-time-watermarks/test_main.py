import importlib.util
from pathlib import Path
import sys
import unittest
_spec = importlib.util.spec_from_file_location('lab_' + Path(__file__).parent.name.replace('-', '_'), Path(__file__).with_name('main.py'))
m = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = m
_spec.loader.exec_module(m)

class WatermarkTests(unittest.TestCase):

    def test_out_of_order_sum(self):
        w = m.Windows(10, 5)
        w.add(8, 2)
        w.add(6, 3)
        self.assertEqual(w.finish(), [{'start': 0, 'end': 10, 'sum': 5, 'count': 2}])

    def test_finalization_and_late_rejection(self):
        w = m.Windows(10, 5)
        w.add(1, 2)
        result = w.add(16, 3)
        self.assertEqual(result['completed'][0]['sum'], 2)
        self.assertFalse(w.add(5, 9)['accepted'])
        self.assertEqual(len(w.finish()), 1)

    def test_half_open_window_boundary(self):
        w = m.Windows(10, 20)
        w.add(9, 1)
        w.add(10, 2)
        self.assertEqual([x['sum'] for x in w.finish()], [1, 2])

    def test_watermark_equality_is_accepted(self):
        w = m.Windows(10, 5)
        w.add(16, 1)
        self.assertTrue(w.add(11, 2)['accepted'])

    def test_finish_closes_stream(self):
        w = m.Windows()
        self.assertEqual(w.finish(), [])
        with self.assertRaises(ValueError):
            w.add(1, 2)
        with self.assertRaises(ValueError):
            w.finish()

    def test_invalid_values(self):
        with self.assertRaises(ValueError):
            m.Windows(width=0)
        with self.assertRaises(ValueError):
            m.Windows().add(-1, 1)
        with self.assertRaises(ValueError):
            m.Windows().add(1, float('nan'))
if __name__ == '__main__':
    unittest.main()
