"""Tumbling event-time sums with deterministic watermarks and late-data policy."""
import argparse
import json
import math

def number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('Finite numbers required')
    return value

class Windows:

    def __init__(self, width=10, disorder=3):
        number(width)
        number(disorder)
        if width <= 0 or disorder < 0:
            raise ValueError('Width must be positive and disorder nonnegative')
        self.width = width
        self.disorder = disorder
        self.maximum = None
        self.watermark = None
        self.windows = {}
        self.closed = False

    def emit(self, all_windows=False):
        result = []
        for start in sorted(self.windows):
            if all_windows or start + self.width <= self.watermark:
                (total, count) = self.windows.pop(start)
                result.append({'start': start, 'end': start + self.width, 'sum': total, 'count': count})
        return result

    def add(self, event_time, value):
        number(event_time)
        number(value)
        if event_time < 0:
            raise ValueError('Event time must be nonnegative')
        if self.closed:
            raise ValueError('Stream has finished')
        if self.watermark is not None and event_time < self.watermark:
            return {'accepted': False, 'reason': 'late', 'watermark': self.watermark, 'completed': []}
        start = math.floor(event_time / self.width) * self.width
        (total, count) = self.windows.get(start, (0, 0))
        total += value
        if not math.isfinite(total) or not math.isfinite(start + self.width):
            raise ValueError('Window arithmetic overflow')
        self.windows[start] = (total, count + 1)
        self.maximum = event_time if self.maximum is None else max(self.maximum, event_time)
        self.watermark = self.maximum - self.disorder
        return {'accepted': True, 'watermark': self.watermark, 'completed': self.emit()}

    def finish(self):
        if self.closed:
            raise ValueError('Stream has finished')
        self.closed = True
        return self.emit(True)

def demo():
    w = Windows(width=10, disorder=5)
    return {'updates': [w.add(t, v) for (t, v) in [(1, 2), (8, 3), (6, 4), (16, 5), (4, 9)]], 'final_windows': w.finish()}
if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    print(json.dumps(demo(), indent=2))
