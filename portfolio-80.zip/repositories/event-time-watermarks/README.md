# Event-time windows and watermarks

Finalize tumbling event-time windows under an explicit bounded-disorder policy.

Educational implementation with synthetic examples.

## Run

Python 3.9 or newer; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

The default example uses synthetic data and needs no credentials, installation, or network connection. The script also works by absolute path from another working directory.

## Behavior

Events enter half-open tumbling windows. Watermark equals maximum observed event time minus allowed disorder. Events strictly before the current watermark are rejected as late; windows whose end is at or before the watermark are emitted once. An explicit finish flushes remaining windows and closes the stream.

## Use in Python

```python
from main import Windows

windows = Windows(width=10, disorder=5)
windows.add(event_time=1, value=2)
completed = windows.add(event_time=16, value=3)['completed']
assert completed[0]['sum'] == 2
remaining = windows.finish()
```

## Design limits

This models one finite stream with a single watermark. It does not coordinate partitions, infer idle sources, deduplicate events, or correct late results. A far-future event advances the watermark, so production timestamp validation is an adapter responsibility. Values are numeric sums, not model observations.

## Verification

The unit tests cover successful operations, failure paths, and invariants. These are local correctness checks, not production performance or security certification.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
