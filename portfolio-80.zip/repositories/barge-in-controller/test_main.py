import unittest
try:
    from .main import BargeInController, replay
except ImportError:
    from main import BargeInController, replay

class BargeTests(unittest.TestCase):

    def test_cancel_once_at_threshold(self):
        events = [{'type': k, 'at_ms': t} for (k, t) in [('tts_start', 0), ('user_start', 10), ('tick', 89), ('tick', 90), ('tick', 100)]]
        result = replay(events)
        self.assertEqual(result['actions'], [{'action': 'cancel_tts', 'at_ms': 90, 'reason': 'sustained_user_activity'}])

    def test_short_activity(self):
        result = replay([{'type': k, 'at_ms': t} for (k, t) in [('tts_start', 0), ('user_start', 10), ('user_end', 40), ('tick', 200)]])
        self.assertEqual(result['actions'], [])
        self.assertTrue(result['assistant_playing'])

    def test_end_event_checks_debounce(self):
        result = replay([{'type': k, 'at_ms': t} for (k, t) in [('tts_start', 0), ('user_start', 10), ('user_end', 100)]])
        self.assertEqual(len(result['actions']), 1)

    def test_no_playback_no_cancel(self):
        self.assertEqual(replay([{'type': 'user_start', 'at_ms': 0}, {'type': 'tick', 'at_ms': 100}])['actions'], [])

    def test_invalid_events_do_not_advance_clock(self):
        c = BargeInController()
        with self.assertRaises(ValueError):
            c.handle({'type': 'user_end', 'at_ms': 10})
        self.assertEqual(c.last_ms, -1)
        c.handle({'type': 'tick', 'at_ms': 10})
        for e in [{'type': 'tick', 'at_ms': 9}, {'type': 'bad', 'at_ms': 12}, {'type': 'tick', 'at_ms': float('nan')}]:
            with self.assertRaises(ValueError):
                c.handle(e)
if __name__ == '__main__':
    unittest.main()
