# Debounced Barge-In Controller

**Demo/starter · Python standard library only.**

Cancel assistant playback only after supplied user-activity events persist beyond a debounce threshold.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json --debounce-ms 80
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input is an ordered JSON event list. Each event has `type` and nonnegative `at_ms`; types are `tts_start`, `tts_end`, `user_start`, `user_end` and `tick`. The controller emits `cancel_tts` once per interrupted playback. Brief activity does not cancel; `user_end` also checks elapsed activity before clearing state.

## Limits and optional provider boundary

User activity is supplied, not detected from audio. A real scheduler must deliver ticks; the controller is not a background timer. Synthetic event timestamps are not measured product latency. No audio is played or recognized.

A VAD adapter could supply activity events and a TTS adapter could execute cancellation. This starter returns action data only.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
