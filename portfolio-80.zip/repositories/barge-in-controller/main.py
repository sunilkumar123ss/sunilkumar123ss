"""Debounce user-activity events before cancelling assistant playback."""
import argparse
import json
import math
from pathlib import Path

class BargeInController:

    def __init__(self, debounce_ms=80):
        if isinstance(debounce_ms, bool) or not isinstance(debounce_ms, (int, float)) or (not math.isfinite(debounce_ms)) or (debounce_ms < 0):
            raise ValueError('debounce_ms must be finite and nonnegative')
        self.debounce_ms = debounce_ms
        self.last_ms = -1
        self.user_since = None
        self.playing = False

    def handle(self, event):
        if not isinstance(event, dict):
            raise ValueError('Event must be an object')
        (kind, now) = (event.get('type'), event.get('at_ms'))
        if kind not in {'tts_start', 'tts_end', 'user_start', 'user_end', 'tick'}:
            raise ValueError('Unknown event type')
        if isinstance(now, bool) or not isinstance(now, (int, float)) or (not math.isfinite(now)) or (now < 0) or (now < self.last_ms):
            raise ValueError('Timestamps must be finite, nonnegative and ordered')
        if kind == 'user_start' and self.user_since is not None:
            raise ValueError('User activity already started')
        if kind == 'user_end' and self.user_since is None:
            raise ValueError('User activity has not started')
        if kind == 'tts_start' and self.playing:
            raise ValueError('Playback already started')
        self.last_ms = now
        if kind == 'tts_start':
            self.playing = True
        elif kind == 'tts_end':
            self.playing = False
        elif kind == 'user_start':
            self.user_since = now
        actions = []
        if self.playing and self.user_since is not None and (now - self.user_since >= self.debounce_ms):
            actions.append({'action': 'cancel_tts', 'at_ms': now, 'reason': 'sustained_user_activity'})
            self.playing = False
        if kind == 'user_end':
            self.user_since = None
        return actions

def replay(events, debounce_ms=80):
    if not isinstance(events, list):
        raise ValueError('events must be a list')
    controller = BargeInController(debounce_ms)
    actions = []
    for event in events:
        actions.extend(controller.handle(event))
    return {'actions': actions, 'assistant_playing': controller.playing, 'user_active': controller.user_since is not None}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON event list: type and at_ms')
    parser.add_argument('--debounce-ms', type=float, default=80)
    args = parser.parse_args()
    try:
        events = json.loads(args.input.read_text()) if args.input else [{'type': 'tts_start', 'at_ms': 0}, {'type': 'user_start', 'at_ms': 100}, {'type': 'tick', 'at_ms': 140}, {'type': 'tick', 'at_ms': 180}, {'type': 'user_end', 'at_ms': 260}]
        print(json.dumps({'source': 'synthetic events' if not args.input else 'provided events', **replay(events, args.debounce_ms)}, indent=2))
    except (ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
