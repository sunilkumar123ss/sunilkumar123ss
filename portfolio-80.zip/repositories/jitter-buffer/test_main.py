import unittest
try:
    from .main import simulate
except ImportError:
    from main import simulate

def p(seq, arrival, text='frame'):
    return {'sequence': seq, 'arrival_ms': arrival, 'payload': text}

class JitterTests(unittest.TestCase):

    def test_reordering(self):
        r = simulate([p(1, 5, 'b'), p(0, 10, 'a')], 2)
        self.assertEqual([f['payload'] for f in r['frames']], ['a', 'b'])

    def test_boundary_and_late(self):
        r = simulate([p(0, 40), p(1, 61)], 2)
        self.assertEqual(r['concealed_frames'], 1)
        self.assertEqual(r['late_packets'], 1)

    def test_duplicate_first_arrival_wins(self):
        r = simulate([p(0, 5, 'a'), p(0, 10, 'b')], 1)
        self.assertEqual(r['duplicate_packets'], 1)
        self.assertEqual(r['frames'][0]['payload'], 'a')

    def test_loss_and_empty(self):
        self.assertEqual(simulate([], 3)['concealed_frames'], 3)
        self.assertEqual(simulate([], 0)['frames'], [])

    def test_invalid(self):
        for (packets, count) in [([p(-1, 0)], 1), ([p(1, 0)], 1), ([p(0, float('inf'))], 1), ([], True)]:
            with self.assertRaises(ValueError):
                simulate(packets, count)
        with self.assertRaises(ValueError):
            simulate([], 1, frame_ms=0)
if __name__ == '__main__':
    unittest.main()
