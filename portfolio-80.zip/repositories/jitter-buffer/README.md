# Deterministic Jitter Buffer

**Demo/starter · Python standard library only.**

Reorder packet arrivals into timed playout and explicitly track missing, late and duplicate packets.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input JSON contains `packets`, `frame_count`, and optional `frame_ms` and `playout_delay_ms`. Each packet has `sequence`, `arrival_ms` and string `payload`. First arrival wins. Arrival exactly at the deadline is playable. Missing frames produce null payloads with `concealed=true`; later packets never rewrite played frames.

## Limits and optional provider boundary

Payloads are labels, not encoded audio. A concealed frame is an explicit null, not synthesized sound. There is no RTP rollover, adaptive delay, live network or wall-clock scheduling. Frame count is limited to 0–10,000.

A transport adapter could supply packet metadata and a codec could conceal loss. Neither is connected in this offline simulation.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
