"""Deterministic sequence-based packet playout with explicit loss concealment."""
import argparse
import json
import math
from pathlib import Path

def simulate(packets, frame_count, frame_ms=20, playout_delay_ms=40):
    if isinstance(frame_count, bool) or not isinstance(frame_count, int) or (not 0 <= frame_count <= 10000):
        raise ValueError('frame_count must be 0..10000')
    for (name, value) in (('frame_ms', frame_ms), ('playout_delay_ms', playout_delay_ms)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or (not math.isfinite(value)) or (value < 0):
            raise ValueError(name + ' must be finite and nonnegative')
    if frame_ms == 0:
        raise ValueError('frame_ms must be positive')
    if not isinstance(packets, list):
        raise ValueError('packets must be a list')
    checked = []
    for packet in packets:
        if not isinstance(packet, dict):
            raise ValueError('Packet must be an object')
        (seq, arrival, payload) = (packet.get('sequence'), packet.get('arrival_ms'), packet.get('payload'))
        if isinstance(seq, bool) or not isinstance(seq, int) or (not 0 <= seq < frame_count):
            raise ValueError('Sequence outside declared session')
        if isinstance(arrival, bool) or not isinstance(arrival, (int, float)) or (not math.isfinite(arrival)) or (arrival < 0):
            raise ValueError('Invalid arrival time')
        if not isinstance(payload, str):
            raise ValueError('Payload must be a string label')
        checked.append((arrival, seq, payload))
    checked.sort(key=lambda x: x[0])
    cursor = 0
    buffer = {}
    seen = set()
    late = duplicates = 0
    output = []
    for expected in range(frame_count):
        deadline = playout_delay_ms + expected * frame_ms
        while cursor < len(checked) and checked[cursor][0] <= deadline:
            (arrival, seq, payload) = checked[cursor]
            cursor += 1
            if seq in seen:
                duplicates += 1
                continue
            seen.add(seq)
            if seq < expected:
                late += 1
            else:
                buffer[seq] = payload
        payload = buffer.pop(expected, None)
        output.append({'sequence': expected, 'playout_ms': deadline, 'payload': payload, 'concealed': payload is None})
    for (arrival, seq, payload) in checked[cursor:]:
        if seq in seen:
            duplicates += 1
        else:
            seen.add(seq)
            late += 1
    return {'frames': output, 'concealed_frames': sum((x['concealed'] for x in output)), 'late_packets': late, 'duplicate_packets': duplicates}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON {packets:[{sequence,arrival_ms,payload}],frame_count,frame_ms?,playout_delay_ms?}')
    args = parser.parse_args()
    try:
        p = json.loads(args.input.read_text()) if args.input else {'frame_count': 4, 'packets': [{'sequence': 1, 'arrival_ms': 15, 'payload': 'frame-B'}, {'sequence': 0, 'arrival_ms': 20, 'payload': 'frame-A'}, {'sequence': 1, 'arrival_ms': 25, 'payload': 'duplicate-B'}, {'sequence': 3, 'arrival_ms': 150, 'payload': 'late-D'}]}
        if not isinstance(p, dict):
            raise ValueError('Input must be an object')
        result = simulate(p['packets'], p['frame_count'], p.get('frame_ms', 20), p.get('playout_delay_ms', 40))
        print(json.dumps({'boundary': 'Packet labels, no codec/audio inference; concealed frames are explicit nulls', **result}, indent=2))
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
