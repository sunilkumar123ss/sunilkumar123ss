# Configuration Validator

Validate application settings together and keep database credentials out of summaries.

All bundled examples use synthetic data.

## Run

Requires Python 3.9 or later; no third-party packages or network access are needed.

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

Run these commands from this repository's directory. The demo can also be launched from any directory by passing the absolute path to `main.py`.

## How it works

The validator consumes a mapping, uses documented defaults, parses booleans and bounded integers, and collects errors before raising `ConfigurationError`. It rejects unknown `APP_` settings to catch typos while ignoring unrelated keys. A database URL is required. The example production policy disables debug mode and requires a PostgreSQL URL.

`Settings.public_summary()` reports the database scheme without credentials or the full URL; the dataclass representation omits the database URL. Parsing never connects to a database. Runtime is O(number and size of configuration entries).

## Reuse

```python
from main import validate_config

settings = validate_config({"APP_DATABASE_URL": "sqlite:///synthetic.db", "APP_PORT": "9000"})
assert settings.port == 9000
assert settings.workers == 2
assert settings.public_summary()["database_scheme"] == "sqlite"
```

## Demo behavior

The default CLI validates a fixed synthetic production mapping. `python3 main.py --environment dev` switches only that demonstration's environment. It does not read your actual process environment. Defaults: environment `dev`, port `8080`, workers `2`, debug `false`, log level `INFO`; database URL has no default.

## Boundaries

The policies are intentionally small and application-specific. URL shape validation does not verify reachability, TLS settings, database existence, or percent-encoded credentials. Supported schemes are `sqlite`, `postgres`, and `postgresql`. The original database URL remains in the returned settings object for a caller to use, so callers must also avoid logging it. This lab does not supply a secrets manager or a deployment configuration system.

## Verification

`test_main.py` exercises boundary conditions, invalid inputs, and meaningful behavior specific to this implementation. The default demo is deterministic and completes without external services. See the collection's verification report for the recorded run; run the commands above to verify this repository independently.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
