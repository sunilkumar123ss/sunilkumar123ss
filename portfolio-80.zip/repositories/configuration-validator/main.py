"""Validate an APP_ configuration mapping and report all errors without echoing secrets."""
import argparse
from dataclasses import dataclass, field
import json
import re
from urllib.parse import urlsplit


KNOWN_KEYS = {"APP_ENV", "APP_PORT", "APP_WORKERS", "APP_DEBUG", "APP_DATABASE_URL", "APP_LOG_LEVEL"}


class ConfigurationError(ValueError):
    def __init__(self, errors):
        self.errors = dict(errors)
        super().__init__("; ".join("{}: {}".format(key, message) for key, message in sorted(errors.items())))


@dataclass(frozen=True)
class Settings:
    environment: str
    port: int
    workers: int
    debug: bool
    database_url: str = field(repr=False)
    log_level: str = "INFO"

    def public_summary(self):
        return {"environment": self.environment, "port": self.port, "workers": self.workers,
                "debug": self.debug, "database_scheme": urlsplit(self.database_url).scheme,
                "log_level": self.log_level}


def validate_config(mapping):
    errors = {}
    for key in mapping:
        if isinstance(key, str) and key.startswith("APP_") and key not in KNOWN_KEYS:
            errors[key] = "unknown application setting"
    values = {}
    for key in KNOWN_KEYS:
        if key in mapping:
            if not isinstance(mapping[key], str):
                errors[key] = "must be a string"
            else:
                values[key] = mapping[key].strip()
    environment = values.get("APP_ENV", "dev").lower()
    if environment not in {"dev", "test", "prod"}:
        errors["APP_ENV"] = "must be dev, test, or prod"

    def integer(key, default, low, high):
        raw = values.get(key, str(default))
        if not re.fullmatch(r"[0-9]{1,6}", raw) or not low <= int(raw) <= high:
            errors[key] = "must be an integer from {} to {}".format(low, high)
            return default
        return int(raw)

    port = integer("APP_PORT", 8080, 1, 65535)
    workers = integer("APP_WORKERS", 2, 1, 32)
    raw_debug = values.get("APP_DEBUG", "false").lower()
    if raw_debug not in {"true", "false", "1", "0", "yes", "no"}:
        errors["APP_DEBUG"] = "must be true, false, 1, 0, yes, or no"
    debug = raw_debug in {"true", "1", "yes"}
    log_level = values.get("APP_LOG_LEVEL", "INFO").upper()
    if log_level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        errors["APP_LOG_LEVEL"] = "unsupported log level"
    database_url = values.get("APP_DATABASE_URL", "")
    scheme = None
    if not database_url:
        errors["APP_DATABASE_URL"] = "is required"
    else:
        try:
            parsed = urlsplit(database_url)
            scheme = parsed.scheme
            if any(character.isspace() for character in database_url):
                raise ValueError("whitespace")
            if scheme == "sqlite":
                if parsed.netloc or not parsed.path.strip("/") or not database_url.startswith("sqlite:///"):
                    raise ValueError("sqlite path")
            elif scheme in {"postgres", "postgresql"}:
                if not parsed.hostname or not parsed.path.strip("/") or parsed.port == 0:
                    raise ValueError("postgres host/database")
            else:
                raise ValueError("scheme")
        except ValueError:
            errors["APP_DATABASE_URL"] = "must be a sqlite:///path or postgres://host/database URL"
    if environment == "prod":
        if debug:
            errors["APP_DEBUG"] = "must be disabled in prod"
        if scheme not in {"postgres", "postgresql"}:
            errors["APP_DATABASE_URL"] = "prod requires a PostgreSQL URL"
    if errors:
        raise ConfigurationError(errors)
    return Settings(environment, port, workers, debug, database_url, log_level)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--environment", choices=("dev", "test", "prod"), default="prod",
                        help="environment for a deterministic synthetic configuration")
    args = parser.parse_args()
    synthetic = {"APP_ENV": args.environment, "APP_PORT": "8080", "APP_WORKERS": "4",
                 "APP_DATABASE_URL": "postgresql://demo:synthetic-password@db.example.invalid/demo"}
    print(json.dumps(validate_config(synthetic).public_summary(), indent=2))


if __name__ == "__main__":
    main()
