import unittest
from main import validate_config, ConfigurationError


class ConfigurationTests(unittest.TestCase):
    def config(self, **changes):
        values = {"APP_DATABASE_URL": "sqlite:///synthetic.db"}
        values.update(changes)
        return values

    def test_defaults_and_non_app_keys(self):
        settings = validate_config(self.config(PATH="ignored"))
        self.assertEqual((settings.port, settings.workers, settings.debug), (8080, 2, False))
        self.assertEqual(settings.environment, "dev")

    def test_errors_accumulate(self):
        with self.assertRaises(ConfigurationError) as caught:
            validate_config(self.config(APP_PORT="70000", APP_WORKERS="0", APP_DEBUG="perhaps"))
        self.assertEqual(set(caught.exception.errors), {"APP_PORT", "APP_WORKERS", "APP_DEBUG"})

    def test_boolean_and_case_normalization(self):
        settings = validate_config(self.config(APP_DEBUG=" YES ", APP_LOG_LEVEL="warning", APP_ENV="TEST"))
        self.assertTrue(settings.debug)
        self.assertEqual(settings.log_level, "WARNING")
        self.assertEqual(settings.environment, "test")

    def test_prod_rules(self):
        with self.assertRaises(ConfigurationError) as caught:
            validate_config(self.config(APP_ENV="prod", APP_DEBUG="true"))
        self.assertEqual(set(caught.exception.errors), {"APP_DATABASE_URL", "APP_DEBUG"})
        settings = validate_config(self.config(APP_ENV="prod", APP_DATABASE_URL="postgresql://db.example.invalid/orders"))
        self.assertEqual(settings.environment, "prod")

    def test_unknown_application_key_rejected(self):
        with self.assertRaises(ConfigurationError) as caught: validate_config(self.config(APP_WOKERS="4"))
        self.assertIn("APP_WOKERS", caught.exception.errors)

    def test_missing_and_malformed_database_urls(self):
        for values in ({}, self.config(APP_DATABASE_URL="postgres://db"),
                       self.config(APP_DATABASE_URL="postgres://db:99999/orders"),
                       self.config(APP_DATABASE_URL="http://db/orders")):
            with self.subTest(values=values), self.assertRaises(ConfigurationError): validate_config(values)

    def test_password_not_in_summary_repr_or_validation_error(self):
        secret = "synthetic-secret-marker"
        settings = validate_config(self.config(APP_DATABASE_URL="postgresql://demo:" + secret + "@db/orders"))
        self.assertNotIn(secret, repr(settings))
        self.assertNotIn(secret, str(settings.public_summary()))
        with self.assertRaises(ConfigurationError) as caught:
            validate_config(self.config(APP_DATABASE_URL="unsupported://" + secret))
        self.assertNotIn(secret, str(caught.exception))

    def test_non_string_value_rejected(self):
        with self.assertRaises(ConfigurationError) as caught: validate_config(self.config(APP_PORT=8080))
        self.assertIn("APP_PORT", caught.exception.errors)

    def test_numeric_boundaries(self):
        self.assertEqual(validate_config(self.config(APP_PORT="1", APP_WORKERS="32")).port, 1)
        self.assertEqual(validate_config(self.config(APP_PORT="65535")).port, 65535)


if __name__ == '__main__':
    unittest.main()
