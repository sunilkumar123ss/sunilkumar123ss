"""Bounded FIFO tasks with expiring ownership tokens."""
import argparse
from collections import deque
import json
import math

class TaskQueue:

    def __init__(self, capacity=3):
        if type(capacity) is not int or capacity < 1:
            raise ValueError('Capacity must be positive')
        self.capacity = capacity
        self.jobs = {}
        self.pending = deque()
        self.seen = set()
        self.sequence = 0
        self.now = 0

    def advance(self, now):
        if type(now) not in (int, float) or not math.isfinite(now) or now < self.now:
            raise ValueError('Finite monotonic time required')
        self.now = now
        for (key, job) in self.jobs.items():
            if job['state'] == 'leased' and job['expires'] <= now:
                job['state'] = 'pending'
                self.pending.append(key)

    def submit(self, key, payload):
        if not isinstance(key, str) or not key or key in self.seen:
            raise ValueError('Unique nonempty ID required')
        if len(self.jobs) >= self.capacity:
            raise OverflowError('Queue is at capacity')
        self.jobs[key] = {'payload': payload, 'state': 'pending', 'attempts': 0}
        self.seen.add(key)
        self.pending.append(key)

    def lease(self, now, ttl=5):
        if type(ttl) not in (int, float) or not math.isfinite(ttl) or ttl <= 0:
            raise ValueError('TTL must be positive')
        if type(now) not in (int, float) or not math.isfinite(now + ttl):
            raise ValueError('Expiration must be finite')
        self.advance(now)
        if not self.pending:
            return None
        key = self.pending.popleft()
        job = self.jobs[key]
        self.sequence += 1
        job.update(state='leased', token=self.sequence, expires=now + ttl, attempts=job['attempts'] + 1)
        return {'id': key, 'token': job['token'], 'payload': job['payload'], 'attempt': job['attempts'], 'expires': job['expires']}

    def complete(self, key, token, now):
        self.advance(now)
        job = self.jobs.get(key)
        if not job or job['state'] != 'leased' or type(token) is not int or (token != job['token']):
            raise ValueError('Stale or unknown lease')
        del self.jobs[key]

def demo():
    q = TaskQueue(2)
    q.submit('synthetic-a', {'task': 'index'})
    q.submit('synthetic-b', {'task': 'evaluate'})
    first = q.lease(0, 2)
    second = q.lease(1, 2)
    q.complete(second['id'], second['token'], 2)
    retry = q.lease(2, 2)
    return {'first_attempt': first, 'second_task': second, 'retried_lease': retry}
if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    print(json.dumps(demo(), indent=2))
