import importlib.util
from pathlib import Path
import sys
import unittest
_spec = importlib.util.spec_from_file_location('lab_' + Path(__file__).parent.name.replace('-', '_'), Path(__file__).with_name('main.py'))
m = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = m
_spec.loader.exec_module(m)

class TaskQueueTests(unittest.TestCase):

    def test_capacity_includes_leased(self):
        q = m.TaskQueue(1)
        q.submit('a', {})
        q.lease(0)
        with self.assertRaises(OverflowError):
            q.submit('b', {})

    def test_completion_releases_capacity(self):
        q = m.TaskQueue(1)
        q.submit('a', {})
        job = q.lease(0)
        q.complete('a', job['token'], 1)
        q.submit('b', {})
        self.assertEqual(q.lease(1)['id'], 'b')

    def test_fifo(self):
        q = m.TaskQueue()
        q.submit('a', 1)
        q.submit('b', 2)
        self.assertEqual([q.lease(0)['id'], q.lease(0)['id']], ['a', 'b'])

    def test_expired_worker_cannot_complete_new_lease(self):
        q = m.TaskQueue()
        q.submit('a', 1)
        old = q.lease(0, 2)
        new = q.lease(2, 2)
        self.assertEqual(new['attempt'], 2)
        with self.assertRaises(ValueError):
            q.complete('a', old['token'], 2)
        q.complete('a', new['token'], 3)

    def test_exact_expiry_is_not_owned(self):
        q = m.TaskQueue()
        q.submit('a', 1)
        job = q.lease(0, 1)
        with self.assertRaises(ValueError):
            q.complete('a', job['token'], 1)

    def test_invalid_time_and_duplicate(self):
        q = m.TaskQueue()
        q.submit('a', 1)
        q.lease(5)
        with self.assertRaises(ValueError):
            q.lease(4)
        with self.assertRaises(ValueError):
            q.submit('a', 2)
if __name__ == '__main__':
    unittest.main()
