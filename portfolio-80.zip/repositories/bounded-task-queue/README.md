# Bounded task queue with leases

Apply backpressure and reject stale completion after an expired task lease.

Educational implementation with synthetic examples.

## Run

Python 3.9 or newer; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

The default example uses synthetic data and needs no credentials, installation, or network connection. The script also works by absolute path from another working directory.

## Behavior

The capacity counts pending and leased jobs. FIFO leasing produces a fresh token for each attempt. Expired leases return to the pending tail. Completion requires the current lease token and a timestamp before expiration.

## Use in Python

```python
from main import TaskQueue

queue = TaskQueue(capacity=2)
queue.submit('example-job', {'task': 'index'})
lease = queue.lease(now=0, ttl=5)
queue.complete(lease['id'], lease['token'], now=1)
```

## Design limits

An in-memory single-process scheduling model, with explicit caller time. It does not cancel a timed-out worker, so external side effects need idempotency. Completed IDs remain in a deduplication set for this process lifetime; there is no persistence or thread safety.

## Verification

The unit tests cover successful operations, failure paths, and invariants. These are local correctness checks, not production performance or security certification.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
