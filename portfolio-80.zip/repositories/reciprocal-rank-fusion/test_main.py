import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
fuse = _main.fuse

class FusionTests(unittest.TestCase):
    def test_multiple_signals_reward_consensus(self):
        result = fuse({"a":["x","z"],"b":["y","z"]}, k=60)
        self.assertEqual(result[0]["id"], "z")
        self.assertEqual(len(result[0]["sources"]), 2)
    def test_duplicates_do_not_inflate_score(self):
        one = fuse({"a":["x"]})[0]["score"]
        self.assertEqual(fuse({"a":["x","x","x"]})[0]["score"], one)
    def test_zero_weight_and_unknown_weight(self):
        self.assertEqual(fuse({"a":["x"]}, weights={"a":0}), [])
        with self.assertRaises(ValueError): fuse({"a":[]}, weights={"unknown":1})
        with self.assertRaises(ValueError): fuse({"a":[]}, k=-1)
    def test_ties_are_deterministic(self):
        self.assertEqual([r["id"] for r in fuse({"a":["b"],"c":["a"]})], ["a","b"])

if __name__ == "__main__": unittest.main()
