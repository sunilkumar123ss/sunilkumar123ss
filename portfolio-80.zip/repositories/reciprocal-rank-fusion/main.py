"""Fuse ranked ID lists without needing incomparable raw similarity scores."""
import argparse
from collections import defaultdict
import json
import math
from pathlib import Path


def fuse(rankings, k=60, weights=None):
    if isinstance(k, bool) or not isinstance(k, (int, float)) or not math.isfinite(k) or k < 0:
        raise ValueError("k must be a finite nonnegative number")
    if not isinstance(rankings, dict) or not rankings:
        raise ValueError("rankings must be a nonempty mapping of signal names to ID lists")
    weights = weights or {}
    if set(weights) - set(rankings):
        raise ValueError("weights contain an unknown ranking signal")
    scores, sources = defaultdict(float), defaultdict(list)
    for signal, ids in rankings.items():
        if not isinstance(signal, str) or not isinstance(ids, list):
            raise ValueError("each signal must have a list")
        weight = weights.get(signal, 1.0)
        if isinstance(weight, bool) or not isinstance(weight, (int, float)) or not math.isfinite(weight) or weight < 0:
            raise ValueError("weights must be finite and nonnegative")
        seen = set()
        for rank, item in enumerate(ids, 1):
            if not isinstance(item, str) or not item:
                raise ValueError("ranked IDs must be nonempty strings")
            if item in seen:
                continue
            seen.add(item)
            if weight:
                scores[item] += weight / (k + rank)
                sources[item].append({"signal": signal, "rank": rank})
    return [{"id": item, "score": round(scores[item], 10), "sources": sources[item]}
            for item in sorted(scores, key=lambda item: (-scores[item], item))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rankings", type=Path, default=Path(__file__).with_name("rankings.json"))
    parser.add_argument("--k", type=float, default=60)
    parser.add_argument("--weights", type=Path, help="optional JSON signal-to-weight mapping")
    args = parser.parse_args()
    try:
        weights = json.loads(args.weights.read_text()) if args.weights else None
        result = fuse(json.loads(args.rankings.read_text()), args.k, weights)
    except (ValueError, OSError, TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, indent=2))

if __name__ == "__main__": main()
