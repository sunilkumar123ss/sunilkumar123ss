# Transactional SQL migrations

Apply ordered SQLite migrations atomically while detecting checksum drift.

Educational implementation with synthetic examples.

## Run

Python 3.9 or newer; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

The default example uses synthetic data and needs no credentials, installation, or network connection. The script also works by absolute path from another working directory.

## Behavior

Each positive integer migration version has immutable SQL text. Pending versions run in ascending order inside one explicit transaction, with checksums recorded in a ledger. Repeating the same set is a no-op. Changed applied SQL and new versions below the applied maximum are rejected.

## Use in Python

```python
import sqlite3
from main import apply

db = sqlite3.connect(':memory:')
try:
    result = apply(db, [{'version': 1,
        'sql': 'CREATE TABLE items(id INTEGER PRIMARY KEY);'}])
    assert result['applied_versions'] == [1]
finally:
    db.close()
```

## Design limits

This runs trusted SQLite DDL/DML, not arbitrary untrusted SQL. Transaction control, attached databases, PRAGMAs, and direct migration-ledger access are denied during migration execution to preserve runner ownership. It provides no down migrations, distributed locks, backup strategy, or compatibility with other SQL engines. Use a dedicated connection with no active transaction: the runner replaces the connection's authorizer callback and leaves an allow-all callback after execution for Python 3.9 compatibility.

## Verification

The unit tests cover successful operations, failure paths, and invariants. These are local correctness checks, not production performance or security certification.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
