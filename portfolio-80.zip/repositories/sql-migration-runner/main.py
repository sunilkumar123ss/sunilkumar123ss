"""Ordered, checksum-protected SQLite migrations in one atomic batch."""
import argparse
import hashlib
import json
import sqlite3

def statements(script):
    pending = ''
    for character in script:
        pending += character
        if character == ';' and sqlite3.complete_statement(pending):
            yield pending
            pending = ''
    if pending.strip():
        candidate = pending + '\n;'
        if not sqlite3.complete_statement(candidate):
            raise ValueError('Incomplete SQL statement')
        yield candidate

def guard(action, arg1, arg2, database, source):
    denied = {sqlite3.SQLITE_TRANSACTION, sqlite3.SQLITE_SAVEPOINT, sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA}
    if action in denied:
        return sqlite3.SQLITE_DENY
    if arg1 == 'schema_migrations' or (action == sqlite3.SQLITE_ALTER_TABLE and arg2 == 'schema_migrations'):
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK

def apply(db, migrations):
    """Use a dedicated connection; the runner replaces its authorizer callback."""
    if db.in_transaction:
        raise ValueError('Complete the caller transaction before migrating')
    if not isinstance(migrations, list):
        raise ValueError('Migrations must be a list')
    normalized = {}
    for row in migrations:
        if not isinstance(row, dict) or set(row) != {'version', 'sql'}:
            raise ValueError('Migrations need version and SQL')
        version = row['version']
        sql = row['sql']
        if type(version) is not int or version < 1 or version in normalized or (not isinstance(sql, str)) or (not sql.strip()):
            raise ValueError('Unique positive versions and nonempty SQL required')
        normalized[version] = (sql, hashlib.sha256(sql.encode()).hexdigest())
    db.execute('CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, checksum TEXT NOT NULL)')
    db.commit()
    db.execute('BEGIN IMMEDIATE')
    applied = []
    try:
        previous = dict(db.execute('SELECT version,checksum FROM schema_migrations'))
        for (version, (_, checksum)) in normalized.items():
            if version in previous and previous[version] != checksum:
                raise ValueError('Applied migration checksum changed')
            if version not in previous and version <= max(previous, default=0):
                raise ValueError('New migration version must exceed applied versions')
        for (version, (sql, checksum)) in sorted(normalized.items()):
            if version in previous:
                continue
            db.set_authorizer(guard)
            try:
                for statement in statements(sql):
                    db.execute(statement)
            finally:
                db.set_authorizer(lambda *args: sqlite3.SQLITE_OK)
            db.execute('INSERT INTO schema_migrations VALUES (?,?)', (version, checksum))
            applied.append(version)
        db.commit()
    except Exception:
        db.set_authorizer(lambda *args: sqlite3.SQLITE_OK)
        db.rollback()
        raise
    return {'applied_versions': applied, 'already_applied': sorted((v for v in normalized if v in previous))}

def demo():
    db = sqlite3.connect(':memory:')
    migrations = [{'version': 1, 'sql': 'CREATE TABLE jobs(id INTEGER PRIMARY KEY, state TEXT NOT NULL);'}, {'version': 2, 'sql': "INSERT INTO jobs VALUES (1,'synthetic-pending');"}]
    try:
        return {'first_run': apply(db, migrations), 'repeat_run': apply(db, migrations), 'rows': db.execute('SELECT * FROM jobs').fetchall()}
    finally:
        db.close()
if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    print(json.dumps(demo(), indent=2))
