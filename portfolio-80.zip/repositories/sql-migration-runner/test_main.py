import importlib.util
from pathlib import Path
import sys
import unittest
_spec = importlib.util.spec_from_file_location('lab_' + Path(__file__).parent.name.replace('-', '_'), Path(__file__).with_name('main.py'))
m = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = m
_spec.loader.exec_module(m)
import sqlite3

class MigrationTests(unittest.TestCase):

    def setUp(self):
        self.db = sqlite3.connect(':memory:')

    def tearDown(self):
        self.db.close()

    def migration(self, version, sql):
        return {'version': version, 'sql': sql}

    def test_applies_in_order_and_is_idempotent(self):
        rows = [self.migration(2, "INSERT INTO items VALUES ('x');"), self.migration(1, 'CREATE TABLE items(value TEXT);')]
        self.assertEqual(m.apply(self.db, rows)['applied_versions'], [1, 2])
        self.assertEqual(m.apply(self.db, rows)['applied_versions'], [])
        self.assertEqual(self.db.execute('SELECT count(*) FROM items').fetchone()[0], 1)

    def test_failure_rolls_back_entire_pending_batch(self):
        with self.assertRaises(sqlite3.Error):
            m.apply(self.db, [self.migration(1, 'CREATE TABLE items(value TEXT);'), self.migration(2, 'INSERT INTO missing VALUES (1);')])
        self.assertEqual(self.db.execute("SELECT name FROM sqlite_master WHERE name='items'").fetchall(), [])
        self.assertEqual(self.db.execute('SELECT * FROM schema_migrations').fetchall(), [])

    def test_checksum_drift_rejected(self):
        m.apply(self.db, [self.migration(1, 'CREATE TABLE items(value TEXT);')])
        with self.assertRaises(ValueError):
            m.apply(self.db, [self.migration(1, 'CREATE TABLE items(value INTEGER);')])

    def test_semicolons_inside_strings_and_comments(self):
        m.apply(self.db, [self.migration(1, "CREATE TABLE items(value TEXT); INSERT INTO items VALUES ('a;b'); -- trailing comment")])
        self.assertEqual(self.db.execute('SELECT value FROM items').fetchone()[0], 'a;b')

    def test_transaction_escape_rejected_and_rolled_back(self):
        with self.assertRaises(sqlite3.Error):
            m.apply(self.db, [self.migration(1, 'CREATE TABLE items(value TEXT); COMMIT;')])
        self.assertEqual(self.db.execute("SELECT name FROM sqlite_master WHERE name='items'").fetchall(), [])

    def test_active_caller_transaction_rejected(self):
        self.db.execute('BEGIN')
        with self.assertRaises(ValueError):
            m.apply(self.db, [])
        self.assertTrue(self.db.in_transaction)

    def test_out_of_order_version_rejected(self):
        m.apply(self.db, [self.migration(2, 'CREATE TABLE items(value TEXT);')])
        with self.assertRaises(ValueError):
            m.apply(self.db, [self.migration(1, 'CREATE TABLE other(value TEXT);')])

    def test_ledger_modification_rejected(self):
        with self.assertRaises(sqlite3.Error):
            m.apply(self.db, [self.migration(1, 'DELETE FROM schema_migrations;')])
if __name__ == '__main__':
    unittest.main()
