# Consistent hash ring

Assign keys to a deterministic virtual-node ring and measure membership remapping.

Educational implementation with synthetic examples.

## Run

Python 3.9 or newer; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

The default example uses synthetic data and needs no credentials, installation, or network connection. The script also works by absolute path from another working directory.

## Behavior

Each node owns SHA-256 positions for a configurable number of virtual nodes. A key goes to the first clockwise token with wraparound. Adding a node can move keys only to that node; removing a node can move only its former keys.

## Use in Python

```python
from main import Ring

ring = Ring(['node-a', 'node-b'], replicas=64)
owner = ring.owner('example-key')
ring.add('node-c')
updated_owner = ring.owner('example-key')
```

## Design limits

This computes placement only. It supplies no replication, migration, failure detection, balancing guarantee, or network transport. Node IDs and replica count must agree across clients. Hash outputs are deterministic; the demonstration counts assignments of synthetic keys rather than benchmarking a distributed cluster.

## Verification

The unit tests cover successful operations, failure paths, and invariants. These are local correctness checks, not production performance or security certification.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
