"""Deterministic consistent hashing with virtual nodes."""
import argparse
import bisect
import hashlib
import json

def digest(kind, *parts):
    return int.from_bytes(hashlib.sha256(json.dumps([kind, *parts], ensure_ascii=False, separators=(',', ':')).encode()).digest(), 'big')

class Ring:

    def __init__(self, nodes=(), replicas=64):
        if type(replicas) is not int or not 1 <= replicas <= 4096:
            raise ValueError('replicas must be 1..4096')
        self.replicas = replicas
        self.nodes = set()
        self.tokens = []
        self.positions = []
        for node in nodes:
            self.add(node)

    def rebuild(self):
        self.tokens = sorted(((digest('node', node, i), node, i) for node in self.nodes for i in range(self.replicas)))
        self.positions = [row[0] for row in self.tokens]

    def add(self, node):
        if not isinstance(node, str) or not node or node in self.nodes:
            raise ValueError('Unique nonempty node ID required')
        self.nodes.add(node)
        self.rebuild()

    def remove(self, node):
        if node not in self.nodes:
            raise ValueError('Unknown node')
        self.nodes.remove(node)
        self.rebuild()

    def owner(self, key):
        if not isinstance(key, str):
            raise ValueError('Key must be a string')
        if not self.tokens:
            raise ValueError('No nodes available')
        index = bisect.bisect_left(self.positions, digest('key', key)) % len(self.tokens)
        return self.tokens[index][1]

def demo():
    ring = Ring(['node-a', 'node-b', 'node-c'])
    before = {str(i): ring.owner(str(i)) for i in range(1000)}
    ring.add('node-d')
    changed = sum((ring.owner(key) != owner for (key, owner) in before.items()))
    counts = {node: sum((ring.owner(key) == node for key in before)) for node in sorted(ring.nodes)}
    return {'synthetic_keys': len(before), 'moved_after_add': changed, 'assignments_after_add': counts}
if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    print(json.dumps(demo(), indent=2))
