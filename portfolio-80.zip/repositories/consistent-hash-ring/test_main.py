import importlib.util
from pathlib import Path
import sys
import unittest
_spec = importlib.util.spec_from_file_location('lab_' + Path(__file__).parent.name.replace('-', '_'), Path(__file__).with_name('main.py'))
m = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = m
_spec.loader.exec_module(m)

class RingTests(unittest.TestCase):

    def test_input_order_does_not_change_ownership(self):
        a = m.Ring(['a', 'b', 'c'])
        b = m.Ring(['c', 'a', 'b'])
        self.assertEqual([a.owner(str(i)) for i in range(200)], [b.owner(str(i)) for i in range(200)])

    def test_single_node_owns_everything(self):
        r = m.Ring(['a'])
        self.assertTrue(all((r.owner(str(i)) == 'a' for i in range(100))))

    def test_add_moves_only_to_new_node(self):
        r = m.Ring(['a', 'b'])
        old = {str(i): r.owner(str(i)) for i in range(1000)}
        r.add('c')
        moved = [key for (key, owner) in old.items() if r.owner(key) != owner]
        self.assertGreater(len(moved), 0)
        self.assertTrue(all((r.owner(key) == 'c' for key in moved)))

    def test_removal_preserves_other_owners(self):
        r = m.Ring(['a', 'b', 'c'])
        old = {str(i): r.owner(str(i)) for i in range(1000)}
        r.remove('b')
        self.assertTrue(all((r.owner(key) == owner for (key, owner) in old.items() if owner != 'b')))

    def test_empty_and_duplicate_rejected(self):
        with self.assertRaises(ValueError):
            m.Ring().owner('x')
        with self.assertRaises(ValueError):
            m.Ring(['a', 'a'])

    def test_readding_restores_mapping(self):
        r = m.Ring(['a', 'b'])
        before = [r.owner(str(i)) for i in range(100)]
        r.remove('b')
        r.add('b')
        self.assertEqual(before, [r.owner(str(i)) for i in range(100)])
if __name__ == '__main__':
    unittest.main()
