import unittest
# Load this project's module explicitly, including when invoked from repository root.
import importlib.util as _import_util
from pathlib import Path as _Path
import sys as _sys
_spec = _import_util.spec_from_file_location(
    "sunil_agents_" + _Path(__file__).parent.name, _Path(__file__).with_name("main.py"))
_main = _import_util.module_from_spec(_spec)
_sys.modules[_spec.name] = _main
_spec.loader.exec_module(_main)
Context = _main.Context
Gateway = _main.Gateway
ToolDenied = _main.ToolDenied

class ToolTests(unittest.TestCase):
    def test_scope_success_and_audit_omits_args(self):
        gateway = Gateway({"secret-item":{"name":"sample"}})
        result = gateway.execute(Context("u",frozenset({"catalog:read"}),100), "catalog.lookup", {"item_id":"secret-item"}, 10)
        self.assertEqual(result["item"]["name"], "sample")
        self.assertNotIn("secret-item", str(gateway.audit))
        self.assertEqual(gateway.audit[0]["outcome"], "allowed")
    def test_expired_missing_scope_and_unknown_denied(self):
        gateway = Gateway({})
        for context,tool in [(Context("u",frozenset(),100),"catalog.lookup"),
                             (Context("u",frozenset({"catalog:read"}),10),"catalog.lookup"),
                             (Context("u",frozenset({"catalog:read"}),100),"shell.run")]:
            with self.subTest(tool=tool), self.assertRaises(ToolDenied):
                gateway.execute(context,tool,{"item_id":"x"},10)
        self.assertTrue(all(x["outcome"] == "denied" for x in gateway.audit))
    def test_nonfinite_clock_cannot_bypass_expiry(self):
        gateway = Gateway({})
        context = Context("u", frozenset({"catalog:read"}), 10)
        for now in [float("nan"), float("inf"), True]:
            with self.assertRaises(ToolDenied):
                gateway.execute(context, "catalog.lookup", {"item_id":"x"}, now)
    def test_untrusted_context_shape_rejected(self):
        gateway = Gateway({})
        for context in [Context(123, frozenset(), 100), Context("u", "catalog:read", 100), {"principal":"u"}]:
            with self.assertRaises(ToolDenied):
                gateway.execute(context, "catalog.lookup", {"item_id":"x"}, 0)
        with self.assertRaises(ToolDenied):
            gateway.execute(Context("u",frozenset({"catalog:read"}),100), [], {}, 0)
    def test_strict_schema_and_nonfinite_rejected(self):
        gateway = Gateway({})
        context = Context("u",frozenset({"math:add"}),100)
        self.assertEqual(gateway.execute(context,"calculator.add",{"a":1,"b":2},0), {"sum":3})
        for params in [{"a":True,"b":2},{"a":float("nan"),"b":1},{"a":1,"b":2,"extra":3}]:
            with self.assertRaises(ToolDenied): gateway.execute(context,"calculator.add",params,0)

if __name__ == "__main__": unittest.main()
