"""A local authorization gate for tool proposals, with minimized audit data."""
import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path

@dataclass(frozen=True)
class Context:
    principal: str
    scopes: frozenset
    expires_at: float


def finite_number(value):
    return type(value) is int or (type(value) is float and math.isfinite(value))


class ToolDenied(ValueError):
    pass


class Gateway:
    def __init__(self, catalog):
        self.catalog = dict(catalog)
        self.audit = []

    def execute(self, context, name, parameters, now):
        if not isinstance(context, Context) or not isinstance(context.principal, str) or not context.principal:
            raise ToolDenied("caller context needs a nonempty principal")
        if not isinstance(context.scopes, frozenset) or any(not isinstance(scope, str) for scope in context.scopes):
            raise ToolDenied("caller scopes must be a trusted frozenset of strings")
        record = {"principal": context.principal, "tool": name if isinstance(name, str) else "<invalid>", "outcome": "denied"}
        self.audit.append(record)
        if not finite_number(now) or not finite_number(context.expires_at) or context.expires_at <= now:
            raise ToolDenied("invalid or expired caller context")
        if not isinstance(name, str):
            raise ToolDenied("tool name must be a string")
        required = {"catalog.lookup": "catalog:read", "calculator.add": "math:add"}
        if name not in required:
            raise ToolDenied("tool is not allowlisted")
        if required[name] not in context.scopes:
            raise ToolDenied("caller lacks the required scope")
        if not isinstance(parameters, dict):
            raise ToolDenied("parameters must be an object")
        if name == "catalog.lookup":
            if set(parameters) != {"item_id"} or not isinstance(parameters["item_id"], str):
                raise ToolDenied("catalog.lookup requires exactly a string item_id")
            result = {"item_id": parameters["item_id"], "item": self.catalog.get(parameters["item_id"])}
        else:
            if set(parameters) != {"a", "b"} or any(not finite_number(v) for v in parameters.values()):
                raise ToolDenied("calculator.add requires exactly finite numbers a and b")
            total = parameters["a"] + parameters["b"]
            if not finite_number(total):
                raise ToolDenied("result is not finite")
            result = {"sum": total}
        record["outcome"] = "allowed"
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tool", default="catalog.lookup")
    parser.add_argument("--params", default='{"item_id":"voice-kit"}')
    parser.add_argument("--scopes", default="catalog:read", help="comma-separated trusted demo scopes")
    args = parser.parse_args()
    gateway = Gateway(json.loads(Path(__file__).with_name("catalog.json").read_text()))
    context = Context("synthetic-demo-user", frozenset(args.scopes.split(",")), 100)
    try:
        result = gateway.execute(context, args.tool, json.loads(args.params), now=50)
        output = {"result": result, "audit": gateway.audit}
    except (ValueError, TypeError) as exc:
        output = {"error": str(exc), "audit": gateway.audit}
        print(json.dumps(output, indent=2))
        raise SystemExit(1)
    print(json.dumps(output, indent=2))

if __name__ == "__main__": main()
