# Scoped tool gateway

Runnable educational demo/starter with synthetic examples.

Checks a static tool allowlist, trusted caller scopes, expiry, and parameter schemas before executing local catalog/calculator tools. The identity/scopes envelope is injected by a trusted caller in this demo; it is not an authenticated token and must not be accepted from an untrusted client in a real service. Audit records omit parameter values. No LLM is involved; a future agent would submit proposals through the same gate.

## Run

Python 3.10+; standard library only. From this directory:

```sh
python3 main.py
python3 main.py --help
python3 -m unittest -v
```

No network requests, credentials, or paid services are used. Any model/provider integration would be a separate adapter. Read `main.py` for the public functions and `test_main.py` for success/failure invariants. Fixture content is synthetic.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
