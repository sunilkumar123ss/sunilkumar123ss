import unittest
try:
    from .main import merge_segments
except ImportError:
    from main import merge_segments

def s(who, start, end):
    return {'speaker': who, 'start_ms': start, 'end_ms': end}

class MergeTests(unittest.TestCase):

    def test_merge_and_account_gap(self):
        r = merge_segments([s('a', 150, 200), s('a', 0, 100)], 50)['segments']
        self.assertEqual(len(r), 1)
        self.assertEqual((r[0]['start_ms'], r[0]['end_ms'], r[0]['bridged_gap_ms']), (0, 200, 50))

    def test_do_not_merge_across_other_speaker(self):
        self.assertEqual(len(merge_segments([s('a', 0, 100), s('b', 110, 120), s('a', 130, 200)], 100)['segments']), 3)

    def test_cross_speaker_overlap(self):
        r = merge_segments([s('a', 0, 100), s('b', 80, 150)])
        self.assertEqual(r['cross_speaker_overlaps'], [{'left_index': 0, 'right_index': 1, 'start_ms': 80, 'end_ms': 100}])

    def test_same_speaker_overlap_union(self):
        r = merge_segments([s('a', 0, 100), s('a', 50, 150)], 0)['segments'][0]
        self.assertEqual(r['end_ms'], 150)
        self.assertEqual(r['bridged_gap_ms'], 0)

    def test_invalid_and_empty(self):
        self.assertEqual(merge_segments([])['segments'], [])
        for item in [s('', 0, 1), s('a', 1, 1), s('a', float('nan'), 1)]:
            with self.assertRaises(ValueError):
                merge_segments([item])
if __name__ == '__main__':
    unittest.main()
