# Speaker-Labeled Segment Merger

**Demo/starter · Python standard library only.**

Merge adjacent same-label time segments and report overlaps between different supplied speaker labels.

All bundled fixtures are synthetic and contain no customer data or secrets.

## Run

Use Python 3.9 or later (validated with Python 3.9.6). No installation or network access is needed. From this project directory:

```sh
python3 main.py
python3 main.py --input fixtures/demo.json --max-gap-ms 100
python3 -m unittest -v
```

The default CLI executes a deterministic working demo. Invalid input exits with a readable error and nonzero status.

## Behavior

Input is a JSON list of `{speaker, start_ms, end_ms}` intervals. The result contains sorted merged intervals, source counts, bridged-gap totals and cross-speaker overlaps. An intervening different-speaker segment prevents merging across it. Same-label overlapping intervals are unioned.

## Limits and optional provider boundary

Speaker labels must already exist. This is not diarization inference, speaker embedding or identity verification. Bridged gaps are reported explicitly and are not claimed to be speech. Overlapping speakers are retained.

An external diarization adapter or human annotation could provide labels. The bundled labels and timings are synthetic.

## Tests

`test_main.py` checks fixed expected results, edge cases and invalid inputs with `unittest`. These tests validate the local implementation, not real-world speech accuracy or production readiness. Run `python3 verify.py` to repeat this repository’s checks.

## Scope

This is an educational implementation with synthetic fixtures. Run the tests and inspect the documented limits before adapting it.

## Repository checks

```sh
python3 verify.py
```

This runs the isolated test suite, synthetic example, and CLI help. The included GitHub Actions workflow repeats these checks when the repository is published. No hosted CI result is claimed by the local verification report.
