"""Merge supplied speaker-labeled intervals; no speaker recognition is performed."""
import argparse
import json
import math
from pathlib import Path

def merge_segments(segments, max_gap_ms=100):
    if isinstance(max_gap_ms, bool) or not isinstance(max_gap_ms, (int, float)) or (not math.isfinite(max_gap_ms)) or (max_gap_ms < 0):
        raise ValueError('max_gap_ms must be finite and nonnegative')
    if not isinstance(segments, list):
        raise ValueError('segments must be a list')
    validated = []
    for item in segments:
        if not isinstance(item, dict):
            raise ValueError('Segment must be an object')
        (speaker, start, end) = (item.get('speaker'), item.get('start_ms'), item.get('end_ms'))
        if not isinstance(speaker, str) or not speaker.strip():
            raise ValueError('Nonempty speaker label required')
        if any((isinstance(x, bool) or not isinstance(x, (int, float)) or (not math.isfinite(x)) or (x < 0) for x in (start, end))) or end <= start:
            raise ValueError('Require finite 0 <= start < end')
        validated.append({'speaker': speaker, 'start_ms': start, 'end_ms': end, 'source_count': 1, 'bridged_gap_ms': 0})
    validated.sort(key=lambda x: (x['start_ms'], x['end_ms'], x['speaker']))
    result = []
    for item in validated:
        if result and result[-1]['speaker'] == item['speaker'] and (item['start_ms'] - result[-1]['end_ms'] <= max_gap_ms):
            prev = result[-1]
            prev['bridged_gap_ms'] += max(0, item['start_ms'] - prev['end_ms'])
            prev['end_ms'] = max(prev['end_ms'], item['end_ms'])
            prev['source_count'] += 1
        else:
            result.append(dict(item))
    overlaps = []
    for (i, left) in enumerate(result):
        for j in range(i + 1, len(result)):
            right = result[j]
            if right['start_ms'] >= left['end_ms']:
                break
            if left['speaker'] != right['speaker']:
                overlaps.append({'left_index': i, 'right_index': j, 'start_ms': max(left['start_ms'], right['start_ms']), 'end_ms': min(left['end_ms'], right['end_ms'])})
    return {'segments': result, 'cross_speaker_overlaps': overlaps}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSON list {speaker,start_ms,end_ms}')
    parser.add_argument('--max-gap-ms', type=float, default=100)
    args = parser.parse_args()
    try:
        items = json.loads(args.input.read_text()) if args.input else [{'speaker': 'speaker-A', 'start_ms': 0, 'end_ms': 300}, {'speaker': 'speaker-A', 'start_ms': 350, 'end_ms': 600}, {'speaker': 'speaker-B', 'start_ms': 550, 'end_ms': 900}]
        print(json.dumps({'boundary': 'Synthetic or externally supplied speaker labels, not diarization inference', **merge_segments(items, args.max_gap_ms)}, indent=2))
    except (ValueError, TypeError, OSError) as exc:
        parser.error(str(exc))
if __name__ == '__main__':
    main()
