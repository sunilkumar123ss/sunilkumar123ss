# Source archive and publication notes

This download contains 80 source packages. The separate profile README repository is not counted among those 80. It includes enhanced RagKit source and the current source files of the other 79 packages; it is not a Git-history archive.

RagKit includes its persistent application, web interface, optional integrations, tests and evidence. Its original standalone demo remains available. The aggregate `verify_all.py` checks only the original standalone reference suites, demos and help. Application-specific verification is documented in `repositories/RagKit/docs/VERIFICATION.md`.

The separately distributed `expanded-history-80.zip`, baseline bundles and audit manifest are preserved. They represent the earlier audited history snapshot, not RagKit’s subsequently enhanced source. RagKit’s repository retains its exact original commit and separately disclosed enhancement milestones.

Repository publication status and scheduling are managed separately from this archive. Extracting or running these source packages does not publish anything or create commits. Consult the profile and repository pages for current hosted state.

The portfolio was created with AI assistance in October 2026. Original project source/history for the six CV projects was unavailable; these are independently written implementations with documented limits. Synthetic historical timestamps do not establish earlier development, employment or deployment. Employer code, credentials, identity records and CV contact details are not included.
