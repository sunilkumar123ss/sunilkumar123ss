# Sunil Kumar — 80-project portfolio

**80 source packages, including enhanced RagKit. Original standalone baseline: 472 tests · 80 demos · 80 CLI help checks.**

Six projects retain their exact CV names. All packages are inspectable educational/reference implementations prepared in October 2026 with AI coding assistance. CV production metrics, adoption claims and historical dates are not claims about these packages.

## Tracks

| Track | Packages |
| --- | ---: |
| Retrieval and agents | 15 |
| Evaluation and ML operations | 15 |
| Voice and audio | 15 |
| CV projects | 6 |
| Backend services | 14 |
| Systems patterns | 15 |

## Quick start

Use Python 3.10 or later for enhanced RagKit. The standalone `main.py` demos use the standard library and need no API keys. RagKit’s web application and optional semantic/provider integrations have their own installation requirements.

```sh
cd repositories/VoiceDesk
python3 main.py
python3 verify.py
```

From the archive root, `python3 verify_all.py` checks the original standalone reference tests, demos and help across all 80 packages. It does not run RagKit’s enhanced application suite. See [collection verification](VERIFICATION.md), [RagKit setup](repositories/RagKit/README.md), [RagKit application evidence](repositories/RagKit/docs/VERIFICATION.md), and [publication notes](PUBLISHING.md).

The source download contains RagKit’s tracked enhanced source at `6309347ed65bbe5eb5aa8779fb10031bc5d3bcc0`, with current documentation for all 80 packages; application code, tests and fixtures are unchanged. The separately distributed expanded-history archive remains the audited baseline history snapshot.

## Project catalog

| Repository package | Scope |
| --- | --- |
| [AlertFlow](repositories/AlertFlow/README.md) | SQLite outbox with idempotency keys, fenced leases, exponential backoff, crash recovery and dead letters. |
| [DataTalk](repositories/DataTalk/README.md) | Constrained question grammar with parameterized SQL, read-only SQLite authorization and VM-step budgets. |
| [HireRank](repositories/HireRank/README.md) | Transparent weighted coverage of supplied technical skill evidence, with missing-evidence explanations and no hiring decisions. |
| [RagKit](repositories/RagKit/README.md) | Persistent document library and web UI with BM25/semantic hybrid retrieval, CrossEncoder reranking, and cited answers; API, CLI, MCP and LangChain integrations. |
| [TripMind](repositories/TripMind/README.md) | Bounded exact itinerary optimization with integer budgets, daily activity constraints and transparent preference scores. |
| [VoiceDesk](repositories/VoiceDesk/README.md) | Offline transcript and playback state machine with barge-in, stale-reply fencing and isolated sessions. |
| [bm25-retriever](repositories/bm25-retriever/README.md) | Ranks a small JSON corpus with BM25 term-frequency scoring. Scores use lexical overlap; they are neither embeddings nor semantic similarity. IDs must be unique. Empty or out-of-vocabulary queries return no hits. This in-memory implementation is intended for small corpora. |
| [bounded-retries](repositories/bounded-retries/README.md) | Retries only explicitly transient failures, with capped exponential backoff, a maximum attempt count, and a total scheduled-delay budget. Permanent errors stop immediately. The default simulation records proposed delays and does not sleep or call a service. This is not a wall-clock execution timeout: a real adapter also needs per-call timeout/cancellation and idempotency protection for side effects. |
| [checkpoint-workflow](repositories/checkpoint-workflow/README.md) | Runs a deterministic document-processing state machine: received → validated → previewed → complete. It persists checkpoints with atomic replacement and validates the document digest and stage outputs on resume. A preview is the first 20 whitespace-separated words, not an AI summary. Use `--checkpoint checkpoint.json --steps 1` repeatedly to exercise resumption. This local demo has no concurrent-writer locking and performs no external side effects. |
| [citation-integrity](repositories/citation-integrity/README.md) | Checks that every cited source exists and the supplied quotation occurs in that source after case/whitespace normalization. It explicitly does not infer whether a quote entails a claim or whether a source is true. The result says “quoted_evidence_found,” not “fact verified.” Missing citations and invented quotations fail. |
| [context-budgeter](repositories/context-budgeter/README.md) | Packs required and optional evidence into a bounded context using a documented word/punctuation-unit estimator. Required evidence either fits completely or causes a clear error; optional evidence is selected by priority with deterministic ties. The estimator is not any provider’s tokenizer, so the budget is not a guarantee of a model context limit. A provider adapter must replace `units` with that model’s actual tokenizer. |
| [evidence-isolation](repositories/evidence-isolation/README.md) | Builds a structured request envelope separating fixed task instructions, the user’s question, and labeled untrusted source text. A conservative pattern scanner adds review flags without deleting source content. A separate tool gate rejects proposals whose provenance is source evidence and accepts only allowlisted trusted-user actions. These structural checks are educational; they do not prove that a language model will resist prompt injection, and the scanner deliberately has false negatives/positives. Trusted provenance must be assigned outside a model or document. |
| [explicit-query-expansion](repositories/explicit-query-expansion/README.md) | Expands queries using reviewed phrase-to-alias rules with provenance, a one-hop limit, and an expansion cap. Rules match complete token sequences, not substrings. Original terms have weight 1 and expansions weight 0.5. These are editorial rules, not generated language, embeddings, or semantic equivalence guarantees. |
| [extractive-qa-abstention](repositories/extractive-qa-abstention/README.md) | Returns a verbatim source sentence when lexical query-term coverage exceeds a configured threshold; otherwise abstains. Every answer includes a source ID and the measured lexical coverage. This is a transparent retrieval baseline, not LLM reasoning, semantic entailment, or a guarantee that a sentence answers the question. |
| [incremental-document-index](repositories/incremental-document-index/README.md) | Hashes UTF-8 `.txt` and `.md` files, detects additions/changes/deletions, and builds a lexical inverted index with per-document term counts. Unchanged files reuse the prior token counts. Symlinked files are skipped, each file is limited to 1 MiB, and malformed prior manifests are rejected. Use `--directory ./documents --state index.json --query "voice"` to persist and query the manifest. Atomic replacement prevents partial JSON writes; concurrent writer coordination is out of scope. |
| [offset-aware-chunker](repositories/offset-aware-chunker/README.md) | Splits text into overlapping whitespace-token windows while retaining exact character offsets and deterministic chunk IDs. Offsets refer to the original Unicode string, not UTF-8 bytes. Chunk size is measured in whitespace tokens, not a model tokenizer. No embedding model is used. |
| [prompt-template-guard](repositories/prompt-template-guard/README.md) | Renders a declared set of simple placeholders, rejects attribute/index traversal, conversions, nested format specifications, undeclared fields, and missing/extra variables. Values are rendered once, so braces inside a value cannot introduce another placeholder. This prevents template misuse; it does not make untrusted text safe from prompt injection in a future model call. |
| [readonly-sqlite-sandbox](repositories/readonly-sqlite-sandbox/README.md) | Executes SQL against a read-only SQLite connection with a table allowlist, SQL authorizer, function allowlist, VM-step budget, row cap, and multi-statement rejection. The default creates an isolated temporary database from the trusted synthetic fixture. Use `--database /path/to/file.db --query "SELECT ..."` for a local database. The table allowlist is `documents`; reads of other tables, writes, PRAGMAs, attachments and extension loading are denied. This is a defense-in-depth demo, not a process/container isolation boundary for hostile SQLite database files. |
| [reciprocal-rank-fusion](repositories/reciprocal-rank-fusion/README.md) | Combines independent ranked ID lists using weighted reciprocal rank fusion (RRF). Duplicate IDs within one signal receive no extra votes. The fixture uses lexical and editorial rankings, not a claimed vector model. RRF scores are relative ranking signals, not calibrated probabilities. |
| [scoped-tool-gateway](repositories/scoped-tool-gateway/README.md) | Checks a static tool allowlist, trusted caller scopes, expiry, and parameter schemas before executing local catalog/calculator tools. The identity/scopes envelope is injected by a trusted caller in this demo; it is not an authenticated token and must not be accepted from an untrusted client in a real service. Audit records omit parameter values. No LLM is involved; a future agent would submit proposals through the same gate. |
| [structured-output-validator](repositories/structured-output-validator/README.md) | Validates a small documented JSON Schema-inspired subset: type, properties, required, additionalProperties, items, enum, string length, number bounds, and array length. Unsupported schema keywords fail explicitly. JSON parsing rejects NaN/Infinity and duplicate keys. Booleans are not accepted as numbers. This is not a complete JSON Schema implementation and cannot verify the factual truth of valid-shaped outputs. |
| [canonical-json-digest](repositories/canonical-json-digest/README.md) | Produce consistent local JSON bytes and content hashes from strict input. |
| [circuit-breaker](repositories/circuit-breaker/README.md) | Explore failure thresholds, short-circuiting, and recovery probes. |
| [configuration-validator](repositories/configuration-validator/README.md) | Validate application settings together and keep database credentials out of summaries. |
| [csv-stream-validator](repositories/csv-stream-validator/README.md) | Validate order imports one record at a time and keep precise decimal totals. |
| [cursor-pagination](repositories/cursor-pagination/README.md) | Page through records using a stable compound key and opaque cursors. |
| [dependency-health-rollup](repositories/dependency-health-rollup/README.md) | Summarize dependency status using criticality and observation freshness. |
| [etag-concurrency](repositories/etag-concurrency/README.md) | Prevent stale JSON updates with atomic compare-and-replace. |
| [idempotency-key-store](repositories/idempotency-key-store/README.md) | Replay successful byte responses while detecting conflicting key reuse. |
| [ndjson-event-reader](repositories/ndjson-event-reader/README.md) | Process bounded event lines while isolating malformed records. |
| [sliding-window-limiter](repositories/sliding-window-limiter/README.md) | Enforce exact request counts over a moving time window. |
| [token-bucket-limiter](repositories/token-bucket-limiter/README.md) | Model burst capacity and gradual token refill with a deterministic clock. |
| [trace-context-parser](repositories/trace-context-parser/README.md) | Inspect version-00 traceparent headers and derive synthetic child contexts. |
| [ttl-lru-cache](repositories/ttl-lru-cache/README.md) | Combine recency-based eviction with per-entry time limits. |
| [webhook-signature-check](repositories/webhook-signature-check/README.md) | Validate raw payload integrity and a bounded timestamp window using HMAC. |
| [budget-routing](repositories/budget-routing/README.md) | Simulate model selection using configured context limits, capabilities, latency estimates and token prices while reserving request costs against a shared batch budget. |
| [classification-metrics](repositories/classification-metrics/README.md) | Evaluate supplied multiclass predictions with a confusion matrix, accuracy, per-class precision/recall/F1, macro F1 and support-weighted F1. |
| [confidence-calibration](repositories/confidence-calibration/README.md) | Inspect supplied binary probabilities with Brier score, log loss, equal-width reliability bins and expected calibration error. |
| [distribution-drift](repositories/distribution-drift/README.md) | Compare numeric samples using fixed-bin population stability index, empirical Kolmogorov-Smirnov distance and standardized mean shift. |
| [model-registry-check](repositories/model-registry-check/README.md) | Check local artifact SHA-256 hashes, confined paths, unique versions, stage rules and required evaluation metadata for production-stage manifest entries. |
| [paired-experiment-comparison](repositories/paired-experiment-comparison/README.md) | Compare experiments with matched random seeds using directional metric improvements and reproducible percentile bootstrap intervals. |
| [release-gate](repositories/release-gate/README.md) | Apply fail-closed thresholds and minimum sample counts to supplied evaluation metrics, with explicit pass, policy-block and invalid-input exit codes. |
| [retrieval-metrics](repositories/retrieval-metrics/README.md) | Score ranked document IDs against supplied relevance grades using precision, recall, reciprocal rank, average precision and nDCG at k. |
| [robustness-perturbations](repositories/robustness-perturbations/README.md) | Generate text variations and assess exact output stability from externally supplied responses, reporting missing observations separately. |
| [split-leakage-guard](repositories/split-leakage-guard/README.md) | Audit small text datasets for duplicate IDs, normalized text shared across splits, shared groups and token-overlap near-duplicate candidates. |
| [synthetic-pii-redaction](repositories/synthetic-pii-redaction/README.md) | Evaluate a limited email/phone regex redactor against annotated character spans, reporting exact-span precision, recall, F1 and missed detections. |
| [token-batch-scheduler](repositories/token-batch-scheduler/README.md) | Simulate FIFO request microbatches under token, item-count and maximum-wait limits, exposing batch composition and per-request waiting times. |
| [token-cost-accounting](repositories/token-cost-accounting/README.md) | Calculate token costs with decimal arithmetic, separate cached-input billing, duplicate request checks and budget reporting using caller-supplied prices. |
| [trace-span-analytics](repositories/trace-span-analytics/README.md) | Validate nested trace spans and compute root latency percentiles, service error counts and exclusive durations without double-subtracting overlapping child spans. |
| [ttl-prompt-cache](repositories/ttl-prompt-cache/README.md) | Demonstrate a local SQLite response cache with contextual request hashes, explicit TTL expiration, upserts, persistence and process-local hit/miss statistics. |
| [audit-hash-chain](repositories/audit-hash-chain/README.md) | Detect changes and reordering in canonical JSON records, with optional trusted head anchoring. |
| [bloom-filter](repositories/bloom-filter/README.md) | Provide bounded approximate membership with mergeable bit arrays. |
| [bounded-task-queue](repositories/bounded-task-queue/README.md) | Apply backpressure and reject stale completion after an expired task lease. |
| [consistent-hash-ring](repositories/consistent-hash-ring/README.md) | Assign keys to a deterministic virtual-node ring and measure membership remapping. |
| [dead-letter-queue](repositories/dead-letter-queue/README.md) | Bound retries and move repeatedly failed jobs into a reviewable dead-letter state. |
| [event-deduplicator](repositories/event-deduplicator/README.md) | Reject repeated event IDs within a bounded first-seen retention window. |
| [event-time-watermarks](repositories/event-time-watermarks/README.md) | Finalize tumbling event-time windows under an explicit bounded-disorder policy. |
| [feature-flag-evaluator](repositories/feature-flag-evaluator/README.md) | Evaluate explicit targeting rules and reproducible percentage rollouts. |
| [merkle-file-manifest](repositories/merkle-file-manifest/README.md) | Detect directory changes using canonical file leaves and a reproducible Merkle root. |
| [rendezvous-hashing](repositories/rendezvous-hashing/README.md) | Choose stable primary and replica candidates by ranking node-specific hashes. |
| [retry-budget](repositories/retry-budget/README.md) | Limit retry amplification using a fractional token budget earned by original requests. |
| [saga-compensation](repositories/saga-compensation/README.md) | Compensate completed steps in reverse order after a later operation fails. |
| [sql-migration-runner](repositories/sql-migration-runner/README.md) | Apply ordered SQLite migrations atomically while detecting checksum drift. |
| [topological-job-planner](repositories/topological-job-planner/README.md) | Calculate dependency-safe earliest schedules and a critical path for a job DAG. |
| [transactional-outbox](repositories/transactional-outbox/README.md) | Commit business records and publishable events in one SQLite transaction. |
| [audio-quality](repositories/audio-quality/README.md) | Measure RMS, dBFS, peak, DC offset, clipping, quiet fraction, zero crossings and crest factor. |
| [barge-in-controller](repositories/barge-in-controller/README.md) | Cancel assistant playback only after supplied user-activity events persist beyond a debounce threshold. |
| [command-router](repositories/command-router/README.md) | Route a small explicit command grammar while refusing ambiguity, negation and low supplied confidence. |
| [dtmf-router](repositories/dtmf-router/README.md) | Route supplied keypad symbols through a small IVR with retry limits, timeouts and human handoff. |
| [energy-vad](repositories/energy-vad/README.md) | Locate sustained high-energy intervals with minimum onset duration and a silence hangover. |
| [jitter-buffer](repositories/jitter-buffer/README.md) | Reorder packet arrivals into timed playout and explicitly track missing, late and duplicate packets. |
| [latency-budget](repositories/latency-budget/README.md) | Build an earliest-start schedule and critical path for a dependency graph of voice pipeline stages. |
| [linear-resampler](repositories/linear-resampler/README.md) | Convert a normalized waveform to another sample rate using explicit linear interpolation. |
| [pcm-converter](repositories/pcm-converter/README.md) | Convert normalized interleaved frames to signed PCM16 little-endian bytes and decode them back. |
| [session-replay](repositories/session-replay/README.md) | Validate a voice-session lifecycle and produce an auditable transition log. |
| [speaker-segment-merge](repositories/speaker-segment-merge/README.md) | Merge adjacent same-label time segments and report overlaps between different supplied speaker labels. |
| [ssml-renderer](repositories/ssml-renderer/README.md) | Render escaped SSML from structured text, emphasis and pause segments. |
| [transcript-stabilizer](repositories/transcript-stabilizer/README.md) | Commit token prefixes shared by consecutive hypotheses while leaving changing text provisional. |
| [wav-segmenter](repositories/wav-segmenter/README.md) | Split a real PCM WAV container into independently playable chunks while preserving frame boundaries, sample rate and channel layout. |
| [word-error-rate](repositories/word-error-rate/README.md) | Compute word-level substitution, deletion and insertion counts with a reproducible edit alignment. |
